####Copyleft Ivan Sanchez Fernandez 2020



########################################PACKAGES########################################
library(shiny)
library(meta)
########################################PACKAGES########################################











##########################################################################################################################
##########################################################BEGINNNING OF UI################################################
##########################################################################################################################
#### ui.R
ui <- fluidPage( 
  # Beginning of fluidPage

  
  tags$br(),
  tags$strong("METAANALYSIS OF RANDOMIZED CLINICAL TRIALS COMPARING INTRAMUSCULAR ACTH VERSUS ORAL PREDNISOLONE FOR INFANTILE SPASMS: Interactively summarize the best available evidence."),
  tags$br(),
  tags$header("This app is optimized for a full-screen computer or tablet. Please, maximize this window."),
  tags$header("Remember to enter appropriate inputs into the model: with inappropriate inputs the model will return inappropriate outputs or errors."),
  tags$strong("If some of the cells are empty the app returns error: WHEN YOU ADD OR MODIFY A STUDY, COMPLETE ALL CELLS TO ELIMINATE THE ERRORS AND SEE RESULTS."),
  tags$br(),
  tags$br(),
  
  sidebarLayout(
    # Beginning of sidebarLayout
    
#########################################BEGINNING OF INPUT########################################################    
    ### INPUT
    sidebarPanel(
      # Beginning of sidebarPanel
      
      fluidRow(
        # Beginning of fluidRow
        
        # Title
        tags$strong("PUBLICATION BIAS CHECKBOX"), 
        tags$header("Check the box to adjust for publication bias (imputted studies in red in the funnel plot)"),
        tags$header("Uncheck the box for unadjusted estimates"),
        checkboxInput("checkbox_publication_bias", label = "Adjust for publication bias", value = FALSE),
        tags$br(),
        tags$br(),
        tags$strong("INPUT"),    
        tags$br(),
        tags$br(),
        
        # Buttons for adding and removing rows
        actionButton("add", "Add new study", icon = icon("plus", class = NULL)),
        
        tags$br(),
        tags$br(),
        tags$br(),
        tags$strong("R: Responders in the subgroup (ACTH or Prednisolone)"),   
        tags$br(),
        tags$strong("N: Population (responders + non reponders) in the subgroup (ACTH or Prednisolone)"),
        tags$br(),
        tags$br(),  
        column(2, tags$strong("Study")),
        column(2, tags$strong("R ACTH")),
        column(2, tags$strong("N ACTH")),
        column(2, tags$strong("R PRD")),
        column(2, tags$strong("N PRD")),
        column(2, tags$strong("Remove study")),
        
        
        #### PLACEHOLDER FOR THE ROWS
        # Placeholder for the rows
        tags$div(id = "placeholder"),
        
#######################################################################################################################################################        
        ########################################STUDIES THAT APPEAR AT BASELINE (IN THE EXISTING LITERATURE TODAY)#####################################
        ## FIRST BASELINE STUDY
        tags$div(
          id = 1,
          fluidRow(
            column(2, textInput(inputId = "studyname1", label = NULL, value = "Lux et al, 2004")
            ),
            column(2, textInput(inputId = "nrespondedACTH1", label = NULL, value = "19")
            ),
            column(2, textInput(inputId = "ntotalACTH1", label = NULL, value = "25")
            ),
            column(2, textInput(inputId = "nrespondedPRD1", label = NULL, value = "21")
            ),
            column(2, textInput(inputId = "ntotalPRD1", label = NULL, value = "30")
            ),
            column(2, actionButton(inputId = "remove1", label = "", icon = icon("times", class = NULL)))
          )),

        ## SECOND BASELINE STUDY
        tags$div(
          id = 2,
          fluidRow(
            column(2, textInput(inputId = "studyname2", label = NULL, value = "Wanigasinghe et al, 2015")
            ),
            column(2, textInput(inputId = "nrespondedACTH2", label = NULL, value = "18")
            ),
            column(2, textInput(inputId = "ntotalACTH2", label = NULL, value = "49")
            ),
            column(2, textInput(inputId = "nrespondedPRD2", label = NULL, value = "28")
            ),
            column(2, textInput(inputId = "ntotalPRD2", label = NULL, value = "48")
            ),
            column(2, actionButton(inputId = "remove2", label = "", icon = icon("times", class = NULL)))
          )),

        ## THIRD BASELINE STUDY
        tags$div(
          id = 3,
          fluidRow(
            column(2, textInput(inputId = "studyname3", label = NULL, value = "Gowda et al, 2019")
            ),
            column(2, textInput(inputId = "nrespondedACTH3", label = NULL, value = "9")
            ),
            column(2, textInput(inputId = "ntotalACTH3", label = NULL, value = "18")
            ),
            column(2, textInput(inputId = "nrespondedPRD3", label = NULL, value = "5")
            ),
            column(2, textInput(inputId = "ntotalPRD3", label = NULL, value = "15")
            ),
            column(2, actionButton(inputId = "remove3", label = "", icon = icon("times", class = NULL)))
          ))

#######################################################################################################################################################        
########################################END OF STUDIES THAT APPEAR AT BASELINE (IN THE EXISTING LITERATURE TODAY)#####################################                
      ) # End of fluidRow
      
      
    ), # End of sidebarPanel
    
#########################################END OF INPUT########################################################    







#########################################BEGINNING OF OUTPUT########################################################    
    ### OUTPUT
    mainPanel(
      # Beginning of mainPanel
      
      # Title
      tags$br(),
      tags$strong("OUTPUT"),    
      tags$br(),
      tags$br(),
      
      fluidRow(
        column(8, 
               tags$strong("RANDOM EFFECTS META-ANALYSIS:"),
               plotOutput("metaanalysis", width = "100%", height = "100%")
               ),
        column(4, 
               tags$strong("FUNNEL PLOT:"),
               plotOutput("publicationbias", width = "100%", height = "100%")
               )
      ),
      tags$br(),
      tags$br(),
      tags$header("Ivan Sanchez Fernandez 2020. This work is copylefted under a General Public Licence (GPL)."),
      tags$header("Users are fee to run, study, and modify this software and to share and distribute original or modified versions of this software.")
      
#########################################END OF OUTPUT########################################################      
      
    ) # End of mainPanel
    
    
  ) # End of sidebarLayout
  
  # End of fluidPage  
)

##########################################################################################################################
##########################################################END OF UI################################################
##########################################################################################################################

















##########################################################################################################################
##########################################################BEGINNNING OF SERVER################################################
##########################################################################################################################

#### server.R
server <- function(input, output) {
  
  
  ## Keep track of elements inserted and not yet removed in the interactive reactivevalues list
  inserted <- reactiveValues(val = c(1, 2, 3))
  
  ## Add a row (a new input) for inserting a new study and a number to the interactive reactivevalues list when "Add new study" button is pressed
  observeEvent(input$add, {
    id <- max(inserted$val) + 1
    insertUI(
      selector = "#placeholder",
      where = "beforeBegin",
      ui = tags$div(
        id = id,
        # Each identifier has the number of that row which is the same id that appears in the interactive reactivevalues list
        fluidRow(
          column(2, textInput(inputId = paste0("studyname", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("nrespondedACTH", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("ntotalACTH", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("nrespondedPRD", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("ntotalPRD", id), label = NULL)
          ),
          column(2, actionButton(inputId = paste0("remove", id), label = "", icon=icon("times", class = NULL))
          )
        ) 
      )
    )
    # Update the interactive reactivevalues list with the new number
    inserted$val <- c(inserted$val, id)
  })
  
  
  
  
  
  #############################################################################################################
  ####################################REMOVE UNWANTED ROWS##################################################### 
  #####################Values for rows 1 to 100 to allow for multiple potential changes in rows 
  
  # When the delete button is pushed, this row (the row with this number) is deleted 
  #and the inserted$val is updated taking out this number of row
  observeEvent(input$remove1,{
    removeUI(
      selector = paste0('#', 1)
    )
    inserted$val <- inserted$val[!inserted$val %in% 1]
  })    
  
  
  observeEvent(input$remove2,{
    removeUI(
      selector = paste0('#', 2)
    )
    inserted$val <- inserted$val[!inserted$val %in% 2]
  })   
  
  
  observeEvent(input$remove3,{
    removeUI(
      selector = paste0('#', 3)
    )
    inserted$val <- inserted$val[!inserted$val %in% 3]
  })    
  
  
  observeEvent(input$remove4,{
    removeUI(
      selector = paste0('#', 4)
    )
    inserted$val <- inserted$val[!inserted$val %in% 4]
  })  
  
  
  observeEvent(input$remove5,{
    removeUI(
      selector = paste0('#', 5)
    )
    inserted$val <- inserted$val[!inserted$val %in% 5]
  })    
  
  
  observeEvent(input$remove6,{
    removeUI(
      selector = paste0('#', 6)
    )
    inserted$val <- inserted$val[!inserted$val %in% 6]
  })   
  
  
  observeEvent(input$remove7,{
    removeUI(
      selector = paste0('#', 7)
    )
    inserted$val <- inserted$val[!inserted$val %in% 7]
  })    
  
  
  observeEvent(input$remove8,{
    removeUI(
      selector = paste0('#', 8)
    )
    inserted$val <- inserted$val[!inserted$val %in% 8]
  })  
  
  
  observeEvent(input$remove9,{
    removeUI(
      selector = paste0('#', 9)
    )
    inserted$val <- inserted$val[!inserted$val %in% 9]
  })    
  
  
  observeEvent(input$remove10,{
    removeUI(
      selector = paste0('#', 10)
    )
    inserted$val <- inserted$val[!inserted$val %in% 10]
  })   
  
  
  observeEvent(input$remove11,{
    removeUI(
      selector = paste0('#', 11)
    )
    inserted$val <- inserted$val[!inserted$val %in% 11]
  })    
  
  
  observeEvent(input$remove12,{
    removeUI(
      selector = paste0('#', 12)
    )
    inserted$val <- inserted$val[!inserted$val %in% 12]
  })   
  
  
  observeEvent(input$remove13,{
    removeUI(
      selector = paste0('#', 13)
    )
    inserted$val <- inserted$val[!inserted$val %in% 13]
  })    
  
  
  observeEvent(input$remove14,{
    removeUI(
      selector = paste0('#', 14)
    )
    inserted$val <- inserted$val[!inserted$val %in% 14]
  })  
  
  
  observeEvent(input$remove15,{
    removeUI(
      selector = paste0('#', 15)
    )
    inserted$val <- inserted$val[!inserted$val %in% 15]
  })    
  
  
  observeEvent(input$remove16,{
    removeUI(
      selector = paste0('#', 16)
    )
    inserted$val <- inserted$val[!inserted$val %in% 16]
  })   
  
  
  observeEvent(input$remove17,{
    removeUI(
      selector = paste0('#', 17)
    )
    inserted$val <- inserted$val[!inserted$val %in% 17]
  })    
  
  
  observeEvent(input$remove18,{
    removeUI(
      selector = paste0('#', 18)
    )
    inserted$val <- inserted$val[!inserted$val %in% 18]
  })  
  
  
  observeEvent(input$remove19,{
    removeUI(
      selector = paste0('#', 19)
    )
    inserted$val <- inserted$val[!inserted$val %in% 19]
  })    
  
  
  observeEvent(input$remove20,{
    removeUI(
      selector = paste0('#', 20)
    )
    inserted$val <- inserted$val[!inserted$val %in% 20]
  })     
  
  
  observeEvent(input$remove21,{
    removeUI(
      selector = paste0('#', 21)
    )
    inserted$val <- inserted$val[!inserted$val %in% 21]
  })    
  
  
  observeEvent(input$remove22,{
    removeUI(
      selector = paste0('#', 22)
    )
    inserted$val <- inserted$val[!inserted$val %in% 22]
  })   
  
  
  observeEvent(input$remove23,{
    removeUI(
      selector = paste0('#', 23)
    )
    inserted$val <- inserted$val[!inserted$val %in% 23]
  })    
  
  
  observeEvent(input$remove24,{
    removeUI(
      selector = paste0('#', 24)
    )
    inserted$val <- inserted$val[!inserted$val %in% 24]
  })  
  
  
  observeEvent(input$remove25,{
    removeUI(
      selector = paste0('#', 25)
    )
    inserted$val <- inserted$val[!inserted$val %in% 25]
  })    
  
  
  observeEvent(input$remove26,{
    removeUI(
      selector = paste0('#', 26)
    )
    inserted$val <- inserted$val[!inserted$val %in% 26]
  })   
  
  
  observeEvent(input$remove27,{
    removeUI(
      selector = paste0('#', 27)
    )
    inserted$val <- inserted$val[!inserted$val %in% 27]
  })    
  
  
  observeEvent(input$remove28,{
    removeUI(
      selector = paste0('#', 28)
    )
    inserted$val <- inserted$val[!inserted$val %in% 28]
  })  
  
  
  observeEvent(input$remove29,{
    removeUI(
      selector = paste0('#', 29)
    )
    inserted$val <- inserted$val[!inserted$val %in% 29]
  })    
  
  
  observeEvent(input$remove30,{
    removeUI(
      selector = paste0('#', 30)
    )
    inserted$val <- inserted$val[!inserted$val %in% 30]
  })    
  
  
  observeEvent(input$remove31,{
    removeUI(
      selector = paste0('#', 31)
    )
    inserted$val <- inserted$val[!inserted$val %in% 31]
  })    
  
  
  observeEvent(input$remove32,{
    removeUI(
      selector = paste0('#', 32)
    )
    inserted$val <- inserted$val[!inserted$val %in% 32]
  })   
  
  
  observeEvent(input$remove33,{
    removeUI(
      selector = paste0('#', 33)
    )
    inserted$val <- inserted$val[!inserted$val %in% 33]
  })    
  
  
  observeEvent(input$remove34,{
    removeUI(
      selector = paste0('#', 34)
    )
    inserted$val <- inserted$val[!inserted$val %in% 34]
  })  
  
  
  observeEvent(input$remove35,{
    removeUI(
      selector = paste0('#', 35)
    )
    inserted$val <- inserted$val[!inserted$val %in% 35]
  })    
  
  
  observeEvent(input$remove36,{
    removeUI(
      selector = paste0('#', 36)
    )
    inserted$val <- inserted$val[!inserted$val %in% 36]
  })   
  
  
  observeEvent(input$remove37,{
    removeUI(
      selector = paste0('#', 37)
    )
    inserted$val <- inserted$val[!inserted$val %in% 37]
  })    
  
  
  observeEvent(input$remove38,{
    removeUI(
      selector = paste0('#', 38)
    )
    inserted$val <- inserted$val[!inserted$val %in% 38]
  })  
  
  
  observeEvent(input$remove39,{
    removeUI(
      selector = paste0('#', 39)
    )
    inserted$val <- inserted$val[!inserted$val %in% 39]
  })    
  
  
  observeEvent(input$remove40,{
    removeUI(
      selector = paste0('#', 40)
    )
    inserted$val <- inserted$val[!inserted$val %in% 40]
  })    
  
  
  observeEvent(input$remove41,{
    removeUI(
      selector = paste0('#', 41)
    )
    inserted$val <- inserted$val[!inserted$val %in% 41]
  })    
  
  
  observeEvent(input$remove42,{
    removeUI(
      selector = paste0('#', 42)
    )
    inserted$val <- inserted$val[!inserted$val %in% 42]
  })   
  
  
  observeEvent(input$remove43,{
    removeUI(
      selector = paste0('#', 43)
    )
    inserted$val <- inserted$val[!inserted$val %in% 43]
  })    
  
  
  observeEvent(input$remove44,{
    removeUI(
      selector = paste0('#', 44)
    )
    inserted$val <- inserted$val[!inserted$val %in% 44]
  })  
  
  
  observeEvent(input$remove45,{
    removeUI(
      selector = paste0('#', 45)
    )
    inserted$val <- inserted$val[!inserted$val %in% 45]
  })    
  
  
  observeEvent(input$remove46,{
    removeUI(
      selector = paste0('#', 46)
    )
    inserted$val <- inserted$val[!inserted$val %in% 46]
  })   
  
  
  observeEvent(input$remove47,{
    removeUI(
      selector = paste0('#', 47)
    )
    inserted$val <- inserted$val[!inserted$val %in% 47]
  })    
  
  
  observeEvent(input$remove48,{
    removeUI(
      selector = paste0('#', 48)
    )
    inserted$val <- inserted$val[!inserted$val %in% 48]
  })  
  
  
  observeEvent(input$remove49,{
    removeUI(
      selector = paste0('#', 49)
    )
    inserted$val <- inserted$val[!inserted$val %in% 49]
  })    
  
  
  observeEvent(input$remove50,{
    removeUI(
      selector = paste0('#', 50)
    )
    inserted$val <- inserted$val[!inserted$val %in% 50]
  })   
  
  
  observeEvent(input$remove51,{
    removeUI(
      selector = paste0('#', 51)
    )
    inserted$val <- inserted$val[!inserted$val %in% 51]
  })    
  
  
  observeEvent(input$remove52,{
    removeUI(
      selector = paste0('#', 52)
    )
    inserted$val <- inserted$val[!inserted$val %in% 52]
  })   
  
  
  observeEvent(input$remove53,{
    removeUI(
      selector = paste0('#', 53)
    )
    inserted$val <- inserted$val[!inserted$val %in% 53]
  })    
  
  
  observeEvent(input$remove54,{
    removeUI(
      selector = paste0('#', 54)
    )
    inserted$val <- inserted$val[!inserted$val %in% 54]
  })  
  
  
  observeEvent(input$remove55,{
    removeUI(
      selector = paste0('#', 55)
    )
    inserted$val <- inserted$val[!inserted$val %in% 55]
  })    
  
  
  observeEvent(input$remove56,{
    removeUI(
      selector = paste0('#', 56)
    )
    inserted$val <- inserted$val[!inserted$val %in% 56]
  })   
  
  
  observeEvent(input$remove57,{
    removeUI(
      selector = paste0('#', 57)
    )
    inserted$val <- inserted$val[!inserted$val %in% 57]
  })    
  
  
  observeEvent(input$remove58,{
    removeUI(
      selector = paste0('#', 58)
    )
    inserted$val <- inserted$val[!inserted$val %in% 58]
  })  
  
  
  observeEvent(input$remove59,{
    removeUI(
      selector = paste0('#', 59)
    )
    inserted$val <- inserted$val[!inserted$val %in% 59]
  })    
  
  
  observeEvent(input$remove60,{
    removeUI(
      selector = paste0('#', 60)
    )
    inserted$val <- inserted$val[!inserted$val %in% 60]
  })     
  
  
  observeEvent(input$remove61,{
    removeUI(
      selector = paste0('#', 61)
    )
    inserted$val <- inserted$val[!inserted$val %in% 61]
  })    
  
  
  observeEvent(input$remove62,{
    removeUI(
      selector = paste0('#', 62)
    )
    inserted$val <- inserted$val[!inserted$val %in% 62]
  })   
  
  
  observeEvent(input$remove63,{
    removeUI(
      selector = paste0('#', 63)
    )
    inserted$val <- inserted$val[!inserted$val %in% 63]
  })    
  
  
  observeEvent(input$remove64,{
    removeUI(
      selector = paste0('#', 64)
    )
    inserted$val <- inserted$val[!inserted$val %in% 64]
  })  
  
  
  observeEvent(input$remove65,{
    removeUI(
      selector = paste0('#', 65)
    )
    inserted$val <- inserted$val[!inserted$val %in% 65]
  })    
  
  
  observeEvent(input$remove66,{
    removeUI(
      selector = paste0('#', 66)
    )
    inserted$val <- inserted$val[!inserted$val %in% 66]
  })   
  
  
  observeEvent(input$remove67,{
    removeUI(
      selector = paste0('#', 67)
    )
    inserted$val <- inserted$val[!inserted$val %in% 67]
  })    
  
  
  observeEvent(input$remove68,{
    removeUI(
      selector = paste0('#', 68)
    )
    inserted$val <- inserted$val[!inserted$val %in% 68]
  })  
  
  
  observeEvent(input$remove69,{
    removeUI(
      selector = paste0('#', 69)
    )
    inserted$val <- inserted$val[!inserted$val %in% 69]
  })    
  
  
  observeEvent(input$remove70,{
    removeUI(
      selector = paste0('#', 70)
    )
    inserted$val <- inserted$val[!inserted$val %in% 70]
  })   
  
  
  observeEvent(input$remove71,{
    removeUI(
      selector = paste0('#', 71)
    )
    inserted$val <- inserted$val[!inserted$val %in% 71]
  })    
  
  
  observeEvent(input$remove72,{
    removeUI(
      selector = paste0('#', 72)
    )
    inserted$val <- inserted$val[!inserted$val %in% 72]
  })   
  
  
  observeEvent(input$remove73,{
    removeUI(
      selector = paste0('#', 73)
    )
    inserted$val <- inserted$val[!inserted$val %in% 73]
  })    
  
  
  observeEvent(input$remove74,{
    removeUI(
      selector = paste0('#', 74)
    )
    inserted$val <- inserted$val[!inserted$val %in% 74]
  })  
  
  
  observeEvent(input$remove75,{
    removeUI(
      selector = paste0('#', 75)
    )
    inserted$val <- inserted$val[!inserted$val %in% 75]
  })    
  
  
  observeEvent(input$remove76,{
    removeUI(
      selector = paste0('#', 76)
    )
    inserted$val <- inserted$val[!inserted$val %in% 76]
  })   
  
  
  observeEvent(input$remove77,{
    removeUI(
      selector = paste0('#', 77)
    )
    inserted$val <- inserted$val[!inserted$val %in% 77]
  })    
  
  
  observeEvent(input$remove78,{
    removeUI(
      selector = paste0('#', 78)
    )
    inserted$val <- inserted$val[!inserted$val %in% 78]
  })  
  
  
  observeEvent(input$remove79,{
    removeUI(
      selector = paste0('#', 79)
    )
    inserted$val <- inserted$val[!inserted$val %in% 79]
  })    
  
  
  observeEvent(input$remove80,{
    removeUI(
      selector = paste0('#', 80)
    )
    inserted$val <- inserted$val[!inserted$val %in% 80]
  })   
  
  
  observeEvent(input$remove81,{
    removeUI(
      selector = paste0('#', 81)
    )
    inserted$val <- inserted$val[!inserted$val %in% 81]
  })    
  
  
  observeEvent(input$remove82,{
    removeUI(
      selector = paste0('#', 82)
    )
    inserted$val <- inserted$val[!inserted$val %in% 82]
  })   
  
  
  observeEvent(input$remove83,{
    removeUI(
      selector = paste0('#', 83)
    )
    inserted$val <- inserted$val[!inserted$val %in% 83]
  })    
  
  
  observeEvent(input$remove84,{
    removeUI(
      selector = paste0('#', 84)
    )
    inserted$val <- inserted$val[!inserted$val %in% 84]
  })  
  
  
  observeEvent(input$remove85,{
    removeUI(
      selector = paste0('#', 85)
    )
    inserted$val <- inserted$val[!inserted$val %in% 85]
  })    
  
  
  observeEvent(input$remove86,{
    removeUI(
      selector = paste0('#', 86)
    )
    inserted$val <- inserted$val[!inserted$val %in% 86]
  })   
  
  
  observeEvent(input$remove87,{
    removeUI(
      selector = paste0('#', 87)
    )
    inserted$val <- inserted$val[!inserted$val %in% 87]
  })    
  
  
  observeEvent(input$remove88,{
    removeUI(
      selector = paste0('#', 88)
    )
    inserted$val <- inserted$val[!inserted$val %in% 88]
  })  
  
  
  observeEvent(input$remove89,{
    removeUI(
      selector = paste0('#', 89)
    )
    inserted$val <- inserted$val[!inserted$val %in% 89]
  })    
  
  
  observeEvent(input$remove90,{
    removeUI(
      selector = paste0('#', 90)
    )
    inserted$val <- inserted$val[!inserted$val %in% 90]
  })   
  

  observeEvent(input$remove91,{
    removeUI(
      selector = paste0('#', 91)
    )
    inserted$val <- inserted$val[!inserted$val %in% 91]
  })    
  
  
  observeEvent(input$remove92,{
    removeUI(
      selector = paste0('#', 92)
    )
    inserted$val <- inserted$val[!inserted$val %in% 92]
  })   
  
  
  observeEvent(input$remove93,{
    removeUI(
      selector = paste0('#', 93)
    )
    inserted$val <- inserted$val[!inserted$val %in% 93]
  })    
  
  
  observeEvent(input$remove94,{
    removeUI(
      selector = paste0('#', 94)
    )
    inserted$val <- inserted$val[!inserted$val %in% 94]
  })  
  
  
  observeEvent(input$remove95,{
    removeUI(
      selector = paste0('#', 95)
    )
    inserted$val <- inserted$val[!inserted$val %in% 95]
  })    
  
  
  observeEvent(input$remove96,{
    removeUI(
      selector = paste0('#', 96)
    )
    inserted$val <- inserted$val[!inserted$val %in% 96]
  })   
  
  
  observeEvent(input$remove97,{
    removeUI(
      selector = paste0('#', 97)
    )
    inserted$val <- inserted$val[!inserted$val %in% 97]
  })    
  
  
  observeEvent(input$remove98,{
    removeUI(
      selector = paste0('#', 98)
    )
    inserted$val <- inserted$val[!inserted$val %in% 98]
  })  
  
  
  observeEvent(input$remove99,{
    removeUI(
      selector = paste0('#', 99)
    )
    inserted$val <- inserted$val[!inserted$val %in% 99]
  })    
  
  
  observeEvent(input$remove100,{
    removeUI(
      selector = paste0('#', 100)
    )
    inserted$val <- inserted$val[!inserted$val %in% 100]
  })   
  
  
  ####################################END OF REMOVE UNWANTED ROWS##################################################### 
###############################################################################################################  
  
  
  
  
  
  

############################################### CREATE METAANALYSIS PLOT#########################################
#################################################################################################################
  output$metaanalysis <- renderPlot({
  
    
## Collect the inputs
## Allow 100 inputs to allow for multiple changes in studies inputs and multiple studies
    
    
    # Studies
    studies <- c(input$studyname1, input$studyname2, input$studyname3, input$studyname4, input$studyname5, 
                 input$studyname6, input$studyname7, input$studyname8, input$studyname9, input$studyname10, 
                 input$studyname11, input$studyname12, input$studyname13, input$studyname14, input$studyname15,
                 input$studyname16, input$studyname17, input$studyname18, input$studyname19, input$studyname20,
                 input$studyname21, input$studyname22, input$studyname23, input$studyname24, input$studyname25,
                 input$studyname26, input$studyname27, input$studyname28, input$studyname29, input$studyname30,
                 input$studyname31, input$studyname32, input$studyname33, input$studyname34, input$studyname35,
                 input$studyname36, input$studyname37, input$studyname38, input$studyname39, input$studyname40,
                 input$studyname41, input$studyname42, input$studyname43, input$studyname44, input$studyname45,
                 input$studyname46, input$studyname47, input$studyname48, input$studyname49, input$studyname50,
                 input$studyname51, input$studyname52, input$studyname53, input$studyname54, input$studyname55,
                 input$studyname56, input$studyname57, input$studyname58, input$studyname59, input$studyname60,
                 input$studyname61, input$studyname62, input$studyname63, input$studyname64, input$studyname65,
                 input$studyname66, input$studyname67, input$studyname68, input$studyname69, input$studyname70,
                 input$studyname71, input$studyname72, input$studyname73, input$studyname74, input$studyname75,
                 input$studyname76, input$studyname77, input$studyname78, input$studyname79, input$studyname80,
                 input$studyname81, input$studyname82, input$studyname83, input$studyname84, input$studyname85,
                 input$studyname86, input$studyname87, input$studyname88, input$studyname89, input$studyname90,
                 input$studyname91, input$studyname92, input$studyname93, input$studyname94, input$studyname95,
                 input$studyname96, input$studyname97, input$studyname98, input$studyname99, input$studyname100)
    # Consider only those studies from studies that have not been deleted and are in the interactive reactivevalues list
    studies <- studies[inserted$val]
    
    
    # Number of patients who responded to ACTH
    respondedACTH <- c(input$nrespondedACTH1, input$nrespondedACTH2, input$nrespondedACTH3, input$nrespondedACTH4, input$nrespondedACTH5, 
                   input$nrespondedACTH6, input$nrespondedACTH7, input$nrespondedACTH8, input$nrespondedACTH9, input$nrespondedACTH10, 
                   input$nrespondedACTH11, input$nrespondedACTH12, input$nrespondedACTH13, input$nrespondedACTH14, input$nrespondedACTH15,
                   input$nrespondedACTH16, input$nrespondedACTH17, input$nrespondedACTH18, input$nrespondedACTH19, input$nrespondedACTH20,
                   input$nrespondedACTH21, input$nrespondedACTH22, input$nrespondedACTH23, input$nrespondedACTH24, input$nrespondedACTH25,
                   input$nrespondedACTH26, input$nrespondedACTH27, input$nrespondedACTH28, input$nrespondedACTH29, input$nrespondedACTH30,
                   input$nrespondedACTH31, input$nrespondedACTH32, input$nrespondedACTH33, input$nrespondedACTH34, input$nrespondedACTH35,
                   input$nrespondedACTH36, input$nrespondedACTH37, input$nrespondedACTH38, input$nrespondedACTH39, input$nrespondedACTH40,
                   input$nrespondedACTH41, input$nrespondedACTH42, input$nrespondedACTH43, input$nrespondedACTH44, input$nrespondedACTH45,
                   input$nrespondedACTH46, input$nrespondedACTH47, input$nrespondedACTH48, input$nrespondedACTH49, input$nrespondedACTH50,
                   input$nrespondedACTH51, input$nrespondedACTH52, input$nrespondedACTH53, input$nrespondedACTH54, input$nrespondedACTH55,
                   input$nrespondedACTH56, input$nrespondedACTH57, input$nrespondedACTH58, input$nrespondedACTH59, input$nrespondedACTH60,
                   input$nrespondedACTH61, input$nrespondedACTH62, input$nrespondedACTH63, input$nrespondedACTH64, input$nrespondedACTH65,
                   input$nrespondedACTH66, input$nrespondedACTH67, input$nrespondedACTH68, input$nrespondedACTH69, input$nrespondedACTH70,
                   input$nrespondedACTH71, input$nrespondedACTH72, input$nrespondedACTH73, input$nrespondedACTH74, input$nrespondedACTH75,
                   input$nrespondedACTH76, input$nrespondedACTH77, input$nrespondedACTH78, input$nrespondedACTH79, input$nrespondedACTH80,
                   input$nrespondedACTH81, input$nrespondedACTH82, input$nrespondedACTH83, input$nrespondedACTH84, input$nrespondedACTH85,
                   input$nrespondedACTH86, input$nrespondedACTH87, input$nrespondedACTH88, input$nrespondedACTH89, input$nrespondedACTH90,
                   input$nrespondedACTH91, input$nrespondedACTH92, input$nrespondedACTH93, input$nrespondedACTH94, input$nrespondedACTH95,
                   input$nrespondedACTH96, input$nrespondedACTH97, input$nrespondedACTH98, input$nrespondedACTH99, input$nrespondedACTH100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    respondedACTH <- respondedACTH[inserted$val]
    respondedACTH <- as.numeric(as.character(respondedACTH))
    
    
    # Total number of patients in the ACTH group
    totalACTH <- c(input$ntotalACTH1, input$ntotalACTH2, input$ntotalACTH3, input$ntotalACTH4, input$ntotalACTH5, 
               input$ntotalACTH6, input$ntotalACTH7, input$ntotalACTH8, input$ntotalACTH9, input$ntotalACTH10, 
               input$ntotalACTH11, input$ntotalACTH12, input$ntotalACTH13, input$ntotalACTH14, input$ntotalACTH15,
               input$ntotalACTH16, input$ntotalACTH17, input$ntotalACTH18, input$ntotalACTH19, input$ntotalACTH20,
               input$ntotalACTH21, input$ntotalACTH22, input$ntotalACTH23, input$ntotalACTH24, input$ntotalACTH25,
               input$ntotalACTH26, input$ntotalACTH27, input$ntotalACTH28, input$ntotalACTH29, input$ntotalACTH30,
               input$ntotalACTH31, input$ntotalACTH32, input$ntotalACTH33, input$ntotalACTH34, input$ntotalACTH35,
               input$ntotalACTH36, input$ntotalACTH37, input$ntotalACTH38, input$ntotalACTH39, input$ntotalACTH40,
               input$ntotalACTH41, input$ntotalACTH42, input$ntotalACTH43, input$ntotalACTH44, input$ntotalACTH45,
               input$ntotalACTH46, input$ntotalACTH47, input$ntotalACTH48, input$ntotalACTH49, input$ntotalACTH50,
               input$ntotalACTH51, input$ntotalACTH52, input$ntotalACTH53, input$ntotalACTH54, input$ntotalACTH55,
               input$ntotalACTH56, input$ntotalACTH57, input$ntotalACTH58, input$ntotalACTH59, input$ntotalACTH60,
               input$ntotalACTH61, input$ntotalACTH62, input$ntotalACTH63, input$ntotalACTH64, input$ntotalACTH65,
               input$ntotalACTH66, input$ntotalACTH67, input$ntotalACTH68, input$ntotalACTH69, input$ntotalACTH70,
               input$ntotalACTH71, input$ntotalACTH72, input$ntotalACTH73, input$ntotalACTH74, input$ntotalACTH75,
               input$ntotalACTH76, input$ntotalACTH77, input$ntotalACTH78, input$ntotalACTH79, input$ntotalACTH80,
               input$ntotalACTH81, input$ntotalACTH82, input$ntotalACTH83, input$ntotalACTH84, input$ntotalACTH85,
               input$ntotalACTH86, input$ntotalACTH87, input$ntotalACTH88, input$ntotalACTH89, input$ntotalACTH90,
               input$ntotalACTH91, input$ntotalACTH92, input$ntotalACTH93, input$ntotalACTH94, input$ntotalACTH95,
               input$ntotalACTH96, input$ntotalACTH97, input$ntotalACTH98, input$ntotalACTH99, input$ntotalACTH100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    totalACTH <- totalACTH[inserted$val]
    totalACTH <- as.numeric(as.character(totalACTH))
    
    
    # Number of patients who responded to Prednisolone
    respondedPRD <- c(input$nrespondedPRD1, input$nrespondedPRD2, input$nrespondedPRD3, input$nrespondedPRD4, input$nrespondedPRD5, 
                       input$nrespondedPRD6, input$nrespondedPRD7, input$nrespondedPRD8, input$nrespondedPRD9, input$nrespondedPRD10, 
                       input$nrespondedPRD11, input$nrespondedPRD12, input$nrespondedPRD13, input$nrespondedPRD14, input$nrespondedPRD15,
                       input$nrespondedPRD16, input$nrespondedPRD17, input$nrespondedPRD18, input$nrespondedPRD19, input$nrespondedPRD20,
                       input$nrespondedPRD21, input$nrespondedPRD22, input$nrespondedPRD23, input$nrespondedPRD24, input$nrespondedPRD25,
                       input$nrespondedPRD26, input$nrespondedPRD27, input$nrespondedPRD28, input$nrespondedPRD29, input$nrespondedPRD30,
                       input$nrespondedPRD31, input$nrespondedPRD32, input$nrespondedPRD33, input$nrespondedPRD34, input$nrespondedPRD35,
                       input$nrespondedPRD36, input$nrespondedPRD37, input$nrespondedPRD38, input$nrespondedPRD39, input$nrespondedPRD40,
                       input$nrespondedPRD41, input$nrespondedPRD42, input$nrespondedPRD43, input$nrespondedPRD44, input$nrespondedPRD45,
                       input$nrespondedPRD46, input$nrespondedPRD47, input$nrespondedPRD48, input$nrespondedPRD49, input$nrespondedPRD50,
                       input$nrespondedPRD51, input$nrespondedPRD52, input$nrespondedPRD53, input$nrespondedPRD54, input$nrespondedPRD55,
                       input$nrespondedPRD56, input$nrespondedPRD57, input$nrespondedPRD58, input$nrespondedPRD59, input$nrespondedPRD60,
                       input$nrespondedPRD61, input$nrespondedPRD62, input$nrespondedPRD63, input$nrespondedPRD64, input$nrespondedPRD65,
                       input$nrespondedPRD66, input$nrespondedPRD67, input$nrespondedPRD68, input$nrespondedPRD69, input$nrespondedPRD70,
                       input$nrespondedPRD71, input$nrespondedPRD72, input$nrespondedPRD73, input$nrespondedPRD74, input$nrespondedPRD75,
                       input$nrespondedPRD76, input$nrespondedPRD77, input$nrespondedPRD78, input$nrespondedPRD79, input$nrespondedPRD80,
                       input$nrespondedPRD81, input$nrespondedPRD82, input$nrespondedPRD83, input$nrespondedPRD84, input$nrespondedPRD85,
                       input$nrespondedPRD86, input$nrespondedPRD87, input$nrespondedPRD88, input$nrespondedPRD89, input$nrespondedPRD90,
                       input$nrespondedPRD91, input$nrespondedPRD92, input$nrespondedPRD93, input$nrespondedPRD94, input$nrespondedPRD95,
                       input$nrespondedPRD96, input$nrespondedPRD97, input$nrespondedPRD98, input$nrespondedPRD99, input$nrespondedPRD100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    respondedPRD <- respondedPRD[inserted$val]    
    respondedPRD <- as.numeric(as.character(respondedPRD))
    
    
    # Total number of patients in the Prednisolone group
    totalPRD <- c(input$ntotalPRD1, input$ntotalPRD2, input$ntotalPRD3, input$ntotalPRD4, input$ntotalPRD5, 
                   input$ntotalPRD6, input$ntotalPRD7, input$ntotalPRD8, input$ntotalPRD9, input$ntotalPRD10, 
                   input$ntotalPRD11, input$ntotalPRD12, input$ntotalPRD13, input$ntotalPRD14, input$ntotalPRD15,
                   input$ntotalPRD16, input$ntotalPRD17, input$ntotalPRD18, input$ntotalPRD19, input$ntotalPRD20,
                   input$ntotalPRD21, input$ntotalPRD22, input$ntotalPRD23, input$ntotalPRD24, input$ntotalPRD25,
                   input$ntotalPRD26, input$ntotalPRD27, input$ntotalPRD28, input$ntotalPRD29, input$ntotalPRD30,
                   input$ntotalPRD31, input$ntotalPRD32, input$ntotalPRD33, input$ntotalPRD34, input$ntotalPRD35,
                   input$ntotalPRD36, input$ntotalPRD37, input$ntotalPRD38, input$ntotalPRD39, input$ntotalPRD40,
                   input$ntotalPRD41, input$ntotalPRD42, input$ntotalPRD43, input$ntotalPRD44, input$ntotalPRD45,
                   input$ntotalPRD46, input$ntotalPRD47, input$ntotalPRD48, input$ntotalPRD49, input$ntotalPRD50,
                   input$ntotalPRD51, input$ntotalPRD52, input$ntotalPRD53, input$ntotalPRD54, input$ntotalPRD55,
                   input$ntotalPRD56, input$ntotalPRD57, input$ntotalPRD58, input$ntotalPRD59, input$ntotalPRD60,
                   input$ntotalPRD61, input$ntotalPRD62, input$ntotalPRD63, input$ntotalPRD64, input$ntotalPRD65,
                   input$ntotalPRD66, input$ntotalPRD67, input$ntotalPRD68, input$ntotalPRD69, input$ntotalPRD70,
                   input$ntotalPRD71, input$ntotalPRD72, input$ntotalPRD73, input$ntotalPRD74, input$ntotalPRD75,
                   input$ntotalPRD76, input$ntotalPRD77, input$ntotalPRD78, input$ntotalPRD79, input$ntotalPRD80,
                   input$ntotalPRD81, input$ntotalPRD82, input$ntotalPRD83, input$ntotalPRD84, input$ntotalPRD85,
                   input$ntotalPRD86, input$ntotalPRD87, input$ntotalPRD88, input$ntotalPRD89, input$ntotalPRD90,
                   input$ntotalPRD91, input$ntotalPRD92, input$ntotalPRD93, input$ntotalPRD94, input$ntotalPRD95,
                   input$ntotalPRD96, input$ntotalPRD97, input$ntotalPRD98, input$ntotalPRD99, input$ntotalPRD100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    totalPRD <- totalPRD[inserted$val]        
    totalPRD <- as.numeric(as.character(totalPRD))
    
    # Create dataframe with the data
    data_metaanalysis <- data.frame(studies, respondedACTH, totalACTH, respondedPRD, totalPRD)
  

    # Calculate non-responders
    data_metaanalysis$notrespondedACTH <- data_metaanalysis$totalACTH - data_metaanalysis$respondedACTH
    data_metaanalysis$notrespondedPRD <- data_metaanalysis$totalPRD - data_metaanalysis$respondedPRD

    # Calculate odds ratio and its log
    data_metaanalysis$OR <- (data_metaanalysis$respondedACTH/data_metaanalysis$respondedPRD) / (data_metaanalysis$notrespondedACTH/data_metaanalysis$notrespondedPRD)
    data_metaanalysis$logOR <- log(data_metaanalysis$OR)

    # Calculate log standard error of OR
    data_metaanalysis$logseOR <- sqrt((1/data_metaanalysis$respondedACTH + 1/data_metaanalysis$notrespondedACTH + 1/data_metaanalysis$respondedPRD + 1/data_metaanalysis$notrespondedPRD))

    # Collect the data for the metaanalysis in a metagen object
    dataformetaanalysis <- metagen(
      TE = data_metaanalysis$logOR,
      seTE = data_metaanalysis$logseOR,
      studlab = data_metaanalysis$studies,
      sm = "OR",
      comb.fixed = FALSE,
      comb.random = TRUE,
      prediction = FALSE
    )

    ## If there is no adjustment for publication bias, create the regular forest plot
    if (input$checkbox_publication_bias==FALSE) {
    
    # Create the forest plot
    forestplot <- forest(dataformetaanalysis, comb.random = TRUE, comb.fixed = FALSE, lty.random=2, lty.fixed = 0, 
                             lwd = 1.75, col.study = "navy", col.square = "gray", col.square.lines = "navy",
                             col.diamond.random = "red", col.diamond.lines.random = "red",
                             print.I2 = TRUE, print.I2.ci = TRUE, print.tau2 = FALSE, print.pval.Q = FALSE,
                             fontsize = 16, fs.heading = 20, fs.hetstat = 16, fs.axis = 16, fs.test.overall = 16,
                             fs.random = 20, fs.smlab = 20, ff.study.labels =  "bold", 
                             ff.axis = "bold", squaresize = 1.2, 
                             backtransf = TRUE, test.overall.random = TRUE, 
                             leftcols = c("studlab", "effect", "ci"), rightcols = FALSE,
                             just = "right", digits = 2)

    
    # Render the forest plot
    forestplot


    ## If there is adjustment for publication bias, create the forest plot with imputted studies
    } else {

      # Trim-and-fill the data 
      dataformetaanalysis_trimandfill <- trimfill(dataformetaanalysis, ma.fixed = TRUE, comb.random = TRUE)


      # Meta-analysis considering subgroups by groups: ACTH and prednisolone
      trimmedandfilledmetaanalysis <- metagen(TE = dataformetaanalysis_trimandfill$TE,

                                              seTE = dataformetaanalysis_trimandfill$seTE,   
                                              
                                              studlab = dataformetaanalysis_trimandfill$studlab,

                                              sm = "OR"
      )

      # Create the forest plot
      forestplot <- forest(trimmedandfilledmetaanalysis, comb.random = TRUE, comb.fixed = FALSE, lty.random=2, lty.fixed = 0, 
                           lwd = 1.75, col.study = "navy", col.square = "gray", col.square.lines = "navy",
                           col.diamond.random = "red", col.diamond.lines.random = "red",
                           print.I2 = TRUE, print.I2.ci = TRUE, print.tau2 = FALSE, print.pval.Q = FALSE,
                           fontsize = 16, fs.heading = 20, fs.hetstat = 16, fs.axis = 16, fs.test.overall = 16,
                           fs.random = 20, fs.smlab = 20, ff.study.labels =  "bold", 
                           ff.axis = "bold", squaresize = 1.2, 
                           backtransf = TRUE, test.overall.random = TRUE, 
                           leftcols = c("studlab", "effect", "ci"), rightcols = FALSE,
                           just = "right", digits = 2)

      # Render the forest plot
      forestplot
    }
    
  }, width = 700, height = 400)
  
  
  
  
  output$publicationbias <- renderPlot({
    
    
    ## Collect the inputs
    ## Allow 100 inputs to allow for multiple changes in studies inputs and multiple studies
    
    
    # Studies
    studies <- c(input$studyname1, input$studyname2, input$studyname3, input$studyname4, input$studyname5, 
                 input$studyname6, input$studyname7, input$studyname8, input$studyname9, input$studyname10, 
                 input$studyname11, input$studyname12, input$studyname13, input$studyname14, input$studyname15,
                 input$studyname16, input$studyname17, input$studyname18, input$studyname19, input$studyname20,
                 input$studyname21, input$studyname22, input$studyname23, input$studyname24, input$studyname25,
                 input$studyname26, input$studyname27, input$studyname28, input$studyname29, input$studyname30,
                 input$studyname31, input$studyname32, input$studyname33, input$studyname34, input$studyname35,
                 input$studyname36, input$studyname37, input$studyname38, input$studyname39, input$studyname40,
                 input$studyname41, input$studyname42, input$studyname43, input$studyname44, input$studyname45,
                 input$studyname46, input$studyname47, input$studyname48, input$studyname49, input$studyname50,
                 input$studyname51, input$studyname52, input$studyname53, input$studyname54, input$studyname55,
                 input$studyname56, input$studyname57, input$studyname58, input$studyname59, input$studyname60,
                 input$studyname61, input$studyname62, input$studyname63, input$studyname64, input$studyname65,
                 input$studyname66, input$studyname67, input$studyname68, input$studyname69, input$studyname70,
                 input$studyname71, input$studyname72, input$studyname73, input$studyname74, input$studyname75,
                 input$studyname76, input$studyname77, input$studyname78, input$studyname79, input$studyname80,
                 input$studyname81, input$studyname82, input$studyname83, input$studyname84, input$studyname85,
                 input$studyname86, input$studyname87, input$studyname88, input$studyname89, input$studyname90,
                 input$studyname91, input$studyname92, input$studyname93, input$studyname94, input$studyname95,
                 input$studyname96, input$studyname97, input$studyname98, input$studyname99, input$studyname100)
    # Consider only those studies from studies that have not been deleted and are in the interactive reactivevalues list
    studies <- studies[inserted$val]
    
    
    # Number of patients who responded to ACTH
    respondedACTH <- c(input$nrespondedACTH1, input$nrespondedACTH2, input$nrespondedACTH3, input$nrespondedACTH4, input$nrespondedACTH5, 
                       input$nrespondedACTH6, input$nrespondedACTH7, input$nrespondedACTH8, input$nrespondedACTH9, input$nrespondedACTH10, 
                       input$nrespondedACTH11, input$nrespondedACTH12, input$nrespondedACTH13, input$nrespondedACTH14, input$nrespondedACTH15,
                       input$nrespondedACTH16, input$nrespondedACTH17, input$nrespondedACTH18, input$nrespondedACTH19, input$nrespondedACTH20,
                       input$nrespondedACTH21, input$nrespondedACTH22, input$nrespondedACTH23, input$nrespondedACTH24, input$nrespondedACTH25,
                       input$nrespondedACTH26, input$nrespondedACTH27, input$nrespondedACTH28, input$nrespondedACTH29, input$nrespondedACTH30,
                       input$nrespondedACTH31, input$nrespondedACTH32, input$nrespondedACTH33, input$nrespondedACTH34, input$nrespondedACTH35,
                       input$nrespondedACTH36, input$nrespondedACTH37, input$nrespondedACTH38, input$nrespondedACTH39, input$nrespondedACTH40,
                       input$nrespondedACTH41, input$nrespondedACTH42, input$nrespondedACTH43, input$nrespondedACTH44, input$nrespondedACTH45,
                       input$nrespondedACTH46, input$nrespondedACTH47, input$nrespondedACTH48, input$nrespondedACTH49, input$nrespondedACTH50,
                       input$nrespondedACTH51, input$nrespondedACTH52, input$nrespondedACTH53, input$nrespondedACTH54, input$nrespondedACTH55,
                       input$nrespondedACTH56, input$nrespondedACTH57, input$nrespondedACTH58, input$nrespondedACTH59, input$nrespondedACTH60,
                       input$nrespondedACTH61, input$nrespondedACTH62, input$nrespondedACTH63, input$nrespondedACTH64, input$nrespondedACTH65,
                       input$nrespondedACTH66, input$nrespondedACTH67, input$nrespondedACTH68, input$nrespondedACTH69, input$nrespondedACTH70,
                       input$nrespondedACTH71, input$nrespondedACTH72, input$nrespondedACTH73, input$nrespondedACTH74, input$nrespondedACTH75,
                       input$nrespondedACTH76, input$nrespondedACTH77, input$nrespondedACTH78, input$nrespondedACTH79, input$nrespondedACTH80,
                       input$nrespondedACTH81, input$nrespondedACTH82, input$nrespondedACTH83, input$nrespondedACTH84, input$nrespondedACTH85,
                       input$nrespondedACTH86, input$nrespondedACTH87, input$nrespondedACTH88, input$nrespondedACTH89, input$nrespondedACTH90,
                       input$nrespondedACTH91, input$nrespondedACTH92, input$nrespondedACTH93, input$nrespondedACTH94, input$nrespondedACTH95,
                       input$nrespondedACTH96, input$nrespondedACTH97, input$nrespondedACTH98, input$nrespondedACTH99, input$nrespondedACTH100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    respondedACTH <- respondedACTH[inserted$val]
    respondedACTH <- as.numeric(as.character(respondedACTH))
    
    
    # Total number of patients in the ACTH group
    totalACTH <- c(input$ntotalACTH1, input$ntotalACTH2, input$ntotalACTH3, input$ntotalACTH4, input$ntotalACTH5, 
                   input$ntotalACTH6, input$ntotalACTH7, input$ntotalACTH8, input$ntotalACTH9, input$ntotalACTH10, 
                   input$ntotalACTH11, input$ntotalACTH12, input$ntotalACTH13, input$ntotalACTH14, input$ntotalACTH15,
                   input$ntotalACTH16, input$ntotalACTH17, input$ntotalACTH18, input$ntotalACTH19, input$ntotalACTH20,
                   input$ntotalACTH21, input$ntotalACTH22, input$ntotalACTH23, input$ntotalACTH24, input$ntotalACTH25,
                   input$ntotalACTH26, input$ntotalACTH27, input$ntotalACTH28, input$ntotalACTH29, input$ntotalACTH30,
                   input$ntotalACTH31, input$ntotalACTH32, input$ntotalACTH33, input$ntotalACTH34, input$ntotalACTH35,
                   input$ntotalACTH36, input$ntotalACTH37, input$ntotalACTH38, input$ntotalACTH39, input$ntotalACTH40,
                   input$ntotalACTH41, input$ntotalACTH42, input$ntotalACTH43, input$ntotalACTH44, input$ntotalACTH45,
                   input$ntotalACTH46, input$ntotalACTH47, input$ntotalACTH48, input$ntotalACTH49, input$ntotalACTH50,
                   input$ntotalACTH51, input$ntotalACTH52, input$ntotalACTH53, input$ntotalACTH54, input$ntotalACTH55,
                   input$ntotalACTH56, input$ntotalACTH57, input$ntotalACTH58, input$ntotalACTH59, input$ntotalACTH60,
                   input$ntotalACTH61, input$ntotalACTH62, input$ntotalACTH63, input$ntotalACTH64, input$ntotalACTH65,
                   input$ntotalACTH66, input$ntotalACTH67, input$ntotalACTH68, input$ntotalACTH69, input$ntotalACTH70,
                   input$ntotalACTH71, input$ntotalACTH72, input$ntotalACTH73, input$ntotalACTH74, input$ntotalACTH75,
                   input$ntotalACTH76, input$ntotalACTH77, input$ntotalACTH78, input$ntotalACTH79, input$ntotalACTH80,
                   input$ntotalACTH81, input$ntotalACTH82, input$ntotalACTH83, input$ntotalACTH84, input$ntotalACTH85,
                   input$ntotalACTH86, input$ntotalACTH87, input$ntotalACTH88, input$ntotalACTH89, input$ntotalACTH90,
                   input$ntotalACTH91, input$ntotalACTH92, input$ntotalACTH93, input$ntotalACTH94, input$ntotalACTH95,
                   input$ntotalACTH96, input$ntotalACTH97, input$ntotalACTH98, input$ntotalACTH99, input$ntotalACTH100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    totalACTH <- totalACTH[inserted$val]
    totalACTH <- as.numeric(as.character(totalACTH))
    
    
    # Number of patients who responded to Prednisolone
    respondedPRD <- c(input$nrespondedPRD1, input$nrespondedPRD2, input$nrespondedPRD3, input$nrespondedPRD4, input$nrespondedPRD5, 
                      input$nrespondedPRD6, input$nrespondedPRD7, input$nrespondedPRD8, input$nrespondedPRD9, input$nrespondedPRD10, 
                      input$nrespondedPRD11, input$nrespondedPRD12, input$nrespondedPRD13, input$nrespondedPRD14, input$nrespondedPRD15,
                      input$nrespondedPRD16, input$nrespondedPRD17, input$nrespondedPRD18, input$nrespondedPRD19, input$nrespondedPRD20,
                      input$nrespondedPRD21, input$nrespondedPRD22, input$nrespondedPRD23, input$nrespondedPRD24, input$nrespondedPRD25,
                      input$nrespondedPRD26, input$nrespondedPRD27, input$nrespondedPRD28, input$nrespondedPRD29, input$nrespondedPRD30,
                      input$nrespondedPRD31, input$nrespondedPRD32, input$nrespondedPRD33, input$nrespondedPRD34, input$nrespondedPRD35,
                      input$nrespondedPRD36, input$nrespondedPRD37, input$nrespondedPRD38, input$nrespondedPRD39, input$nrespondedPRD40,
                      input$nrespondedPRD41, input$nrespondedPRD42, input$nrespondedPRD43, input$nrespondedPRD44, input$nrespondedPRD45,
                      input$nrespondedPRD46, input$nrespondedPRD47, input$nrespondedPRD48, input$nrespondedPRD49, input$nrespondedPRD50,
                      input$nrespondedPRD51, input$nrespondedPRD52, input$nrespondedPRD53, input$nrespondedPRD54, input$nrespondedPRD55,
                      input$nrespondedPRD56, input$nrespondedPRD57, input$nrespondedPRD58, input$nrespondedPRD59, input$nrespondedPRD60,
                      input$nrespondedPRD61, input$nrespondedPRD62, input$nrespondedPRD63, input$nrespondedPRD64, input$nrespondedPRD65,
                      input$nrespondedPRD66, input$nrespondedPRD67, input$nrespondedPRD68, input$nrespondedPRD69, input$nrespondedPRD70,
                      input$nrespondedPRD71, input$nrespondedPRD72, input$nrespondedPRD73, input$nrespondedPRD74, input$nrespondedPRD75,
                      input$nrespondedPRD76, input$nrespondedPRD77, input$nrespondedPRD78, input$nrespondedPRD79, input$nrespondedPRD80,
                      input$nrespondedPRD81, input$nrespondedPRD82, input$nrespondedPRD83, input$nrespondedPRD84, input$nrespondedPRD85,
                      input$nrespondedPRD86, input$nrespondedPRD87, input$nrespondedPRD88, input$nrespondedPRD89, input$nrespondedPRD90,
                      input$nrespondedPRD91, input$nrespondedPRD92, input$nrespondedPRD93, input$nrespondedPRD94, input$nrespondedPRD95,
                      input$nrespondedPRD96, input$nrespondedPRD97, input$nrespondedPRD98, input$nrespondedPRD99, input$nrespondedPRD100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    respondedPRD <- respondedPRD[inserted$val]    
    respondedPRD <- as.numeric(as.character(respondedPRD))
    
    
    # Total number of patients in the Prednisolone group
    totalPRD <- c(input$ntotalPRD1, input$ntotalPRD2, input$ntotalPRD3, input$ntotalPRD4, input$ntotalPRD5, 
                  input$ntotalPRD6, input$ntotalPRD7, input$ntotalPRD8, input$ntotalPRD9, input$ntotalPRD10, 
                  input$ntotalPRD11, input$ntotalPRD12, input$ntotalPRD13, input$ntotalPRD14, input$ntotalPRD15,
                  input$ntotalPRD16, input$ntotalPRD17, input$ntotalPRD18, input$ntotalPRD19, input$ntotalPRD20,
                  input$ntotalPRD21, input$ntotalPRD22, input$ntotalPRD23, input$ntotalPRD24, input$ntotalPRD25,
                  input$ntotalPRD26, input$ntotalPRD27, input$ntotalPRD28, input$ntotalPRD29, input$ntotalPRD30,
                  input$ntotalPRD31, input$ntotalPRD32, input$ntotalPRD33, input$ntotalPRD34, input$ntotalPRD35,
                  input$ntotalPRD36, input$ntotalPRD37, input$ntotalPRD38, input$ntotalPRD39, input$ntotalPRD40,
                  input$ntotalPRD41, input$ntotalPRD42, input$ntotalPRD43, input$ntotalPRD44, input$ntotalPRD45,
                  input$ntotalPRD46, input$ntotalPRD47, input$ntotalPRD48, input$ntotalPRD49, input$ntotalPRD50,
                  input$ntotalPRD51, input$ntotalPRD52, input$ntotalPRD53, input$ntotalPRD54, input$ntotalPRD55,
                  input$ntotalPRD56, input$ntotalPRD57, input$ntotalPRD58, input$ntotalPRD59, input$ntotalPRD60,
                  input$ntotalPRD61, input$ntotalPRD62, input$ntotalPRD63, input$ntotalPRD64, input$ntotalPRD65,
                  input$ntotalPRD66, input$ntotalPRD67, input$ntotalPRD68, input$ntotalPRD69, input$ntotalPRD70,
                  input$ntotalPRD71, input$ntotalPRD72, input$ntotalPRD73, input$ntotalPRD74, input$ntotalPRD75,
                  input$ntotalPRD76, input$ntotalPRD77, input$ntotalPRD78, input$ntotalPRD79, input$ntotalPRD80,
                  input$ntotalPRD81, input$ntotalPRD82, input$ntotalPRD83, input$ntotalPRD84, input$ntotalPRD85,
                  input$ntotalPRD86, input$ntotalPRD87, input$ntotalPRD88, input$ntotalPRD89, input$ntotalPRD90,
                  input$ntotalPRD91, input$ntotalPRD92, input$ntotalPRD93, input$ntotalPRD94, input$ntotalPRD95,
                  input$ntotalPRD96, input$ntotalPRD97, input$ntotalPRD98, input$ntotalPRD99, input$ntotalPRD100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    totalPRD <- totalPRD[inserted$val]        
    totalPRD <- as.numeric(as.character(totalPRD))
    
    # Create dataframe with the data
    data_metaanalysis <- data.frame(studies, respondedACTH, totalACTH, respondedPRD,totalPRD)
    
    
    # Calculate non-responders
    data_metaanalysis$notrespondedACTH <- data_metaanalysis$totalACTH - data_metaanalysis$respondedACTH
    data_metaanalysis$notrespondedPRD <- data_metaanalysis$totalPRD - data_metaanalysis$respondedPRD
    
    # Calculate odds ratio and its log
    data_metaanalysis$OR <- (data_metaanalysis$respondedACTH/data_metaanalysis$respondedPRD) / (data_metaanalysis$notrespondedACTH/data_metaanalysis$notrespondedPRD)
    data_metaanalysis$logOR <- log(data_metaanalysis$OR)
    
    # Calculate log standard error of OR
    data_metaanalysis$logseOR <- sqrt((1/data_metaanalysis$respondedACTH + 1/data_metaanalysis$notrespondedACTH + 1/data_metaanalysis$respondedPRD + 1/data_metaanalysis$notrespondedPRD))
    
    # Collect the data for the metaanalysis in a metagen object
    dataformetaanalysis <- metagen(
      TE = data_metaanalysis$logOR,
      seTE = data_metaanalysis$logseOR,
      studlab = data_metaanalysis$studies,
      sm = "OR",
      comb.fixed = FALSE,
      comb.random = TRUE,
      prediction = FALSE
    )
    
    ## If there is no adjustment for publication bias, create the regular funnel plot
    if (input$checkbox_publication_bias==FALSE) {
      
      # Create the publication bias plot
      publicationbiasplot <- funnel(dataformetaanalysis, comb.fixed = FALSE, comb.random = TRUE, 
                                        pch = 21, cex = 1.5,
                                        lty.random = 2, lwd.random = 2, bg = "navy", col = "navy",
                                        studlab = FALSE)
      
      
      # Render the publication bias plot
      publicationbiasplot
      
      
      ## If there is adjustment for publication bias, create the forest plot with imputted studies
    } else {
      
      # Trim-and-fill the data 
      dataformetaanalysis_trimandfill <- trimfill(dataformetaanalysis, ma.fixed = TRUE, comb.random = TRUE)
      
      
      # Meta-analysis considering subgroups by groups: ACTH and prednisolone
      trimmedandfilledmetaanalysis <- metagen(TE = dataformetaanalysis_trimandfill$TE,
                                              
                                              seTE = dataformetaanalysis_trimandfill$seTE,   
                                              
                                              studlab = dataformetaanalysis_trimandfill$studlab,
                                              
                                              sm = "OR"
      )
      
      # Create the forest plot
      # Create the publication bias plot
      publicationbiasplot <- funnel(trimmedandfilledmetaanalysis, comb.fixed = FALSE, comb.random = TRUE, 
                                        pch = 21, cex = 1.5,
                                        lty.random = 2, lwd.random = 2, 
                                        bg = c(rep("navy", length(dataformetaanalysis$studlab)), 
                                               rep("red", length(trimmedandfilledmetaanalysis$studlab)-length(dataformetaanalysis$studlab))), 
                                        col = c(rep("navy", length(dataformetaanalysis$studlab)), 
                                                rep("red", length(trimmedandfilledmetaanalysis$studlab)-length(dataformetaanalysis$studlab))),
                                        studlab = FALSE)
      
      
      # Render the publication bias plot
      publicationbiasplot
    }
    
  }, width = 400, height = 400)
  
  

  
}
##########################################################################################################################
##########################################################END OF SERVER################################################
##########################################################################################################################





##########################################################################################################################
##########################################################RUN THE APP WITH UI AND SERVER###############################################
##########################################################################################################################
#### Run the app
shinyApp(ui = ui, server = server)