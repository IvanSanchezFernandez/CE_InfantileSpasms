####Copyleft Ivan Sanchez Fernandez 2020



########################################PACKAGES########################################
library(shiny)
library(meta)
########################################PACKAGES########################################











##########################################################################################################################
##########################################################BEGINNNING OF UI################################################
##########################################################################################################################
#### ui.R
ui <- fluidPage( 
  # Beginning of fluidPage

  
  tags$br(),
  tags$strong("METAANALYSIS OF INTRAMUSCULAR ACTH VERSUS ORAL STEROIDS FOR INFANTILE SPASMS: Interactively summarize the best available evidence."),
  tags$br(),
  tags$header("This app is optimized for a full-screen computer or tablet. Please, maximize this window."),
  tags$header("Remember to enter appropriate inputs into the model: with inappropriate inputs the model will return inappropriate outputs or errors."),
  tags$strong("If some of the cells are empty the app returns error: WHEN YOU ADD OR MODIFY A STUDY, COMPLETE ALL CELLS TO ELIMINATE THE ERRORS AND SEE RESULTS."),
  tags$br(),
  tags$br(),
  
  sidebarLayout(
    # Beginning of sidebarLayout
    
#########################################BEGINNING OF INPUT########################################################    
    ### INPUT
    sidebarPanel(
      # Beginning of sidebarPanel
      
      fluidRow(
        # Beginning of fluidRow
        
        # Title
        tags$strong("PUBLICATION BIAS CHECKBOX"), 
        tags$header("Check the box to adjust for publication bias (imputted studies in red in the funnel plot)"),
        tags$header("Uncheck the box for unadjusted estimates"),
        checkboxInput("checkbox_publication_bias", label = "Adjust for publication bias", value = FALSE),
        tags$br(),
        tags$br(),
        tags$strong("INPUT"),    
        tags$br(),
        tags$br(),
        
        
        # Buttons for adding and removing rows
        actionButton("add", "Add new study", icon = icon("plus", class = NULL)),
        
        tags$br(),
        tags$br(),
        column(2, tags$strong("Treatment")), 
        column(4, tags$strong("Study")),
        column(2, tags$strong("N response")),
        column(2, tags$strong("N total")),
        column(2, tags$strong("Remove study")),
        
        
        #### PLACEHOLDER FOR THE ROWS
        # Placeholder for the rows
        tags$div(id = "placeholder"),
        
#######################################################################################################################################################        
        ########################################STUDIES THAT APPEAR AT BASELINE (IN THE EXISTING LITERATURE TODAY)#####################################
        ## FIRST BASELINE STUDY
        tags$div(
          id = 1,
          fluidRow(
            column(2, textInput(inputId = "Treatment1", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname1", label = NULL, value = "Hrachovy et al, 1983")
            ),
            column(2, textInput(inputId = "nresponded1", label = NULL, value = "7")
            ),
            column(2, textInput(inputId = "ntotal1", label = NULL, value = "12")
            ),
            column(2, actionButton(inputId = "remove1", label = "", icon = icon("times", class = NULL)))
          )),
        
        ## SECOND BASELINE STUDY
        tags$div(
          id = 2,
          fluidRow(
            column(2, textInput(inputId = "Treatment2", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname2", label = NULL, value = "Snead et al, 1989")
            ),
            column(2, textInput(inputId = "nresponded2", label = NULL, value = "12")
            ),
            column(2, textInput(inputId = "ntotal2", label = NULL, value = "15")
            ),
            column(2, actionButton(inputId = "remove2", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## THIRD BASELINE STUDY
        tags$div(
          id = 3,
          fluidRow(
            column(2, textInput(inputId = "Treatment3", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname3", label = NULL, value = "Baram et al, 1996")
            ),
            column(2, textInput(inputId = "nresponded3", label = NULL, value = "14")
            ),
            column(2, textInput(inputId = "ntotal3", label = NULL, value = "15")
            ),
            column(2, actionButton(inputId = "remove3", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## FOURTH BASELINE STUDY
        tags$div(
          id = 4,
          fluidRow(
            column(2, textInput(inputId = "Treatment4", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname4", label = NULL, value = "Vigevano & Cilio, 1997")
            ),
            column(2, textInput(inputId = "nresponded4", label = NULL, value = "14")
            ),
            column(2, textInput(inputId = "ntotal4", label = NULL, value = "19")
            ),
            column(2, actionButton(inputId = "remove4", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## FIFTH BASELINE STUDY
        tags$div(
          id = 5,
          fluidRow(
            column(2, textInput(inputId = "Treatment5", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname5", label = NULL, value = "Yanagaki et al, 1999")
            ),
            column(2, textInput(inputId = "nresponded5", label = NULL, value = "11")
            ),
            column(2, textInput(inputId = "ntotal5", label = NULL, value = "13")
            ),
            column(2, actionButton(inputId = "remove5", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## SIXTH BASELINE STUDY
        tags$div(
          id = 6,
          fluidRow(
            column(2, textInput(inputId = "Treatment6", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname6", label = NULL, value = "Lux et al, 2004")
            ),
            column(2, textInput(inputId = "nresponded6", label = NULL, value = "19")
            ),
            column(2, textInput(inputId = "ntotal6", label = NULL, value = "25")
            ),
            column(2, actionButton(inputId = "remove6", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## SEVENTH BASELINE STUDY
        tags$div(
          id = 7,
          fluidRow(
            column(2, textInput(inputId = "Treatment7", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname7", label = NULL, value = "Lin et al, 2006")
            ),
            column(2, textInput(inputId = "nresponded7", label = NULL, value = "46")
            ),
            column(2, textInput(inputId = "ntotal7", label = NULL, value = "53")
            ),
            column(2, actionButton(inputId = "remove7", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## EIGHTH BASELINE STUDY
        tags$div(
          id = 8,
          fluidRow(
            column(2, textInput(inputId = "Treatment8", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname8", label = NULL, value = "Kossoff et al, 2008")
            ),
            column(2, textInput(inputId = "nresponded8", label = NULL, value = "17")
            ),
            column(2, textInput(inputId = "ntotal8", label = NULL, value = "20")
            ),
            column(2, actionButton(inputId = "remove8", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## NINTH BASELINE STUDY
        tags$div(
          id = 9,
          fluidRow(
            column(2, textInput(inputId = "Treatment9", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname9", label = NULL, value = "Cohen-Sadan et al, 2009")
            ),
            column(2, textInput(inputId = "nresponded9", label = NULL, value = "11")
            ),
            column(2, textInput(inputId = "ntotal9", label = NULL, value = "14")
            ),
            column(2, actionButton(inputId = "remove9", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## TENTH BASELINE STUDY
        tags$div(
          id = 10,
          fluidRow(
            column(2, textInput(inputId = "Treatment10", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname10", label = NULL, value = "Wanigasinghe et al, 2015")
            ),
            column(2, textInput(inputId = "nresponded10", label = NULL, value = "18")
            ),
            column(2, textInput(inputId = "ntotal10", label = NULL, value = "49")
            ),
            column(2, actionButton(inputId = "remove10", label = "", icon = icon("times", class = NULL)))
          )),

                
        ## ELEVENTH BASELINE STUDY
        tags$div(
          id = 11,
          fluidRow(
            column(2, textInput(inputId = "Treatment11", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname11", label = NULL, value = "Knupp et al, 2016")
            ),
            column(2, textInput(inputId = "nresponded11", label = NULL, value = "66")
            ),
            column(2, textInput(inputId = "ntotal11", label = NULL, value = "97")
            ),
            column(2, actionButton(inputId = "remove11", label = "", icon = icon("times", class = NULL)))
          )),        
        
  
        ## TWELTH BASELINE STUDY
        tags$div(
          id = 12,
          fluidRow(
            column(2, textInput(inputId = "Treatment12", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname12", label = NULL, value = "Hodgeman et al, 2016")
            ),
            column(2, textInput(inputId = "nresponded12", label = NULL, value = "40")
            ),
            column(2, textInput(inputId = "ntotal12", label = NULL, value = "57")
            ),
            column(2, actionButton(inputId = "remove12", label = "", icon = icon("times", class = NULL)))
          )),         

                
        ## THIRTEENTH BASELINE STUDY
        tags$div(
          id = 13,
          fluidRow(
            column(2, textInput(inputId = "Treatment13", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname13", label = NULL, value = "Yin et al, 2017")
            ),
            column(2, textInput(inputId = "nresponded13", label = NULL, value = "52")
            ),
            column(2, textInput(inputId = "ntotal13", label = NULL, value = "111")
            ),
            column(2, actionButton(inputId = "remove13", label = "", icon = icon("times", class = NULL)))
          )),         
              
 
        ## FOURTEENTH BASELINE STUDY
        tags$div(
          id = 14,
          fluidRow(
            column(2, textInput(inputId = "Treatment14", label = NULL, value = "ACTH")
            ),
            column(4, textInput(inputId = "studyname14", label = NULL, value = "Gowda et al, 2019")
            ),
            column(2, textInput(inputId = "nresponded14", label = NULL, value = "9")
            ),
            column(2, textInput(inputId = "ntotal14", label = NULL, value = "18")
            ),
            column(2, actionButton(inputId = "remove14", label = "", icon = icon("times", class = NULL)))
          )),         

        
        ## FIFTEENTH BASELINE STUDY
        tags$div(
          id = 15,
          fluidRow(
            column(2, textInput(inputId = "Treatment15", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname15", label = NULL, value = "Lux et al, 2004")
            ),
            column(2, textInput(inputId = "nresponded15", label = NULL, value = "21")
            ),
            column(2, textInput(inputId = "ntotal15", label = NULL, value = "30")
            ),
            column(2, actionButton(inputId = "remove15", label = "", icon = icon("times", class = NULL)))
          )),
        

        ## SIXTEENTH BASELINE STUDY
        tags$div(
          id = 16,
          fluidRow(
            column(2, textInput(inputId = "Treatment16", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname16", label = NULL, value = "Ware et al, 2012")
            ),
            column(2, textInput(inputId = "nresponded16", label = NULL, value = "13")
            ),
            column(2, textInput(inputId = "ntotal16", label = NULL, value = "17")
            ),
            column(2, actionButton(inputId = "remove16", label = "", icon = icon("times", class = NULL)))
          )),
        
               
        ## SEVENTEENTH BASELINE STUDY
        tags$div(
          id = 17,
          fluidRow(
            column(2, textInput(inputId = "Treatment17", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname17", label = NULL, value = "Adhami & Harini, 2013")
            ),
            column(2, textInput(inputId = "nresponded17", label = NULL, value = "7")
            ),
            column(2, textInput(inputId = "ntotal17", label = NULL, value = "7")
            ),
            column(2, actionButton(inputId = "remove17", label = "", icon = icon("times", class = NULL)))
          )),     
   
             
        ## EIGHTEENTH BASELINE STUDY
        tags$div(
          id = 18,
          fluidRow(
            column(2, textInput(inputId = "Treatment18", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname18", label = NULL, value = "Chellamuthu et al, 2014")
            ),
            column(2, textInput(inputId = "nresponded18", label = NULL, value = "16")
            ),
            column(2, textInput(inputId = "ntotal18", label = NULL, value = "31")
            ),
            column(2, actionButton(inputId = "remove18", label = "", icon = icon("times", class = NULL)))
          )),      
        
 
        ## NINETEENTH BASELINE STUDY
        tags$div(
          id = 19,
          fluidRow(
            column(2, textInput(inputId = "Treatment19", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname19", label = NULL, value = "Wanigasinghe et al, 2015")
            ),
            column(2, textInput(inputId = "nresponded19", label = NULL, value = "28")
            ),
            column(2, textInput(inputId = "ntotal19", label = NULL, value = "48")
            ),
            column(2, actionButton(inputId = "remove19", label = "", icon = icon("times", class = NULL)))
          )),        
        
        
        ## TWENTIETH BASELINE STUDY
        tags$div(
          id = 20,
          fluidRow(
            column(2, textInput(inputId = "Treatment20", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname20", label = NULL, value = "Yi et al, 2015")
            ),
            column(2, textInput(inputId = "nresponded20", label = NULL, value = "16")
            ),
            column(2, textInput(inputId = "ntotal20", label = NULL, value = "20")
            ),
            column(2, actionButton(inputId = "remove20", label = "", icon = icon("times", class = NULL)))
          )),          
        

        ## TWENTY-FIRST BASELINE STUDY
        tags$div(
          id = 21,
          fluidRow(
            column(2, textInput(inputId = "Treatment21", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname21", label = NULL, value = "Knupp et al, 2016")
            ),
            column(2, textInput(inputId = "nresponded21", label = NULL, value = "30")
            ),
            column(2, textInput(inputId = "ntotal21", label = NULL, value = "54")
            ),
            column(2, actionButton(inputId = "remove21", label = "", icon = icon("times", class = NULL)))
          )),         

        
        ## TWENTY-SECOND BASELINE STUDY
        tags$div(
          id = 22,
          fluidRow(
            column(2, textInput(inputId = "Treatment22", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname22", label = NULL, value = "Gonzalez-Giraldo et al, 2018")
            ),
            column(2, textInput(inputId = "nresponded22", label = NULL, value = "62")
            ),
            column(2, textInput(inputId = "ntotal22", label = NULL, value = "87")
            ),
            column(2, actionButton(inputId = "remove22", label = "", icon = icon("times", class = NULL)))
          )),       

        
        ## TWENTY-THIRD BASELINE STUDY
        tags$div(
          id = 23,
          fluidRow(
            column(2, textInput(inputId = "Treatment23", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname23", label = NULL, value = "Eliyan et al, 2019")
            ),
            column(2, textInput(inputId = "nresponded23", label = NULL, value = "60")
            ),
            column(2, textInput(inputId = "ntotal23", label = NULL, value = "102")
            ),
            column(2, actionButton(inputId = "remove23", label = "", icon = icon("times", class = NULL)))
          )),    


        ## TWENTy-FOURTH BASELINE STUDY
        tags$div(
          id = 24,
          fluidRow(
            column(2, textInput(inputId = "Treatment24", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname24", label = NULL, value = "Yi et al, 2019")
            ),
            column(2, textInput(inputId = "nresponded24", label = NULL, value = "28")
            ),
            column(2, textInput(inputId = "ntotal24", label = NULL, value = "39")
            ),
            column(2, actionButton(inputId = "remove24", label = "", icon = icon("times", class = NULL)))
          )),    
        
        
        ## TWENTy-FIFTH BASELINE STUDY
        tags$div(
          id = 25,
          fluidRow(
            column(2, textInput(inputId = "Treatment25", label = NULL, value = "Oral steroids")
            ),
            column(4, textInput(inputId = "studyname25", label = NULL, value = "Gowda et al, 2019")
            ),
            column(2, textInput(inputId = "nresponded25", label = NULL, value = "5")
            ),
            column(2, textInput(inputId = "ntotal25", label = NULL, value = "15")
            ),
            column(2, actionButton(inputId = "remove25", label = "", icon = icon("times", class = NULL)))
          ))   

#######################################################################################################################################################        
########################################END OF STUDIES THAT APPEAR AT BASELINE (IN THE EXISTING LITERATURE TODAY)#####################################                
      ) # End of fluidRow
      
      
    ), # End of sidebarPanel
    
#########################################END OF INPUT########################################################    







#########################################BEGINNING OF OUTPUT########################################################    
    ### OUTPUT
    mainPanel(
      # Beginning of mainPanel
      
      # Title
      tags$br(),
      tags$strong("OUTPUT"),    
      tags$br(),
      tags$br(),
      
      fluidRow(
        column(8, 
               tags$strong("RANDOM EFFECTS META-ANALYSIS:"),
               plotOutput("metaanalysis", width = "100%", height = "100%")
               ),
        column(4, 
               tags$strong("FUNNEL PLOT FOR ACTH:"),
               plotOutput("publicationbiasACTH", width = "100%", height = "100%"),
               tags$br(),
               tags$br(),
               tags$br(),
               tags$br(),
               tags$strong("FUNNEL PLOT FOR ORAL STEROIDS:"),
               plotOutput("publicationbiasPRD", width = "100%", height = "100%")
               )
      ),
      tags$br(),
      tags$br(),
      tags$header("Ivan Sanchez Fernandez 2020. This work is copylefted under a General Public Licence (GPL)."),
      tags$header("Users are fee to run, study, and modify this software and to share and distribute original or modified versions of this software.")
      
#########################################END OF OUTPUT########################################################      
      
    ) # End of mainPanel
    
    
  ) # End of sidebarLayout
  
  # End of fluidPage  
)

##########################################################################################################################
##########################################################END OF UI################################################
##########################################################################################################################

















##########################################################################################################################
##########################################################BEGINNNING OF SERVER################################################
##########################################################################################################################

#### server.R
server <- function(input, output) {
  
  
  ## Keep track of elements inserted and not yet removed in the interactive reactivevalues list
  inserted <- reactiveValues(val = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 
                                     21, 22, 23, 24, 25))
  
  ## Add a row (a new input) for inserting a new study and a number to the interactive reactivevalues list when "Add new study" button is pressed
  observeEvent(input$add, {
    id <- max(inserted$val) + 1
    insertUI(
      selector = "#placeholder",
      where = "beforeBegin",
      ui = tags$div(
        id = id,
        # Each identifier has the number of that row which is the same id that appears in the interactive reactivevalues list
        fluidRow(
          column(2, textInput(inputId = paste0("Treatment", id), label = NULL)
          ),
          column(4, textInput(inputId = paste0("studyname", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("nresponded", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("ntotal", id), label = NULL)
          ),
          column(2, actionButton(inputId = paste0("remove", id), label = "", icon=icon("times", class = NULL))
          )
        ) 
      )
    )
    # Update the interactive reactivevalues list with the new number
    inserted$val <- c(inserted$val, id)
  })
  
  
  
  
  
  #############################################################################################################
  ####################################REMOVE UNWANTED ROWS##################################################### 
  #####################Values for rows 1 to 100 to allow for multiple potential changes in rows 
  
  # When the delete button is pushed, this row (the row with this number) is deleted 
  #and the inserted$val is updated taking out this number of row
  observeEvent(input$remove1,{
    removeUI(
      selector = paste0('#', 1)
    )
    inserted$val <- inserted$val[!inserted$val %in% 1]
  })    
  
  
  observeEvent(input$remove2,{
    removeUI(
      selector = paste0('#', 2)
    )
    inserted$val <- inserted$val[!inserted$val %in% 2]
  })   
  
  
  observeEvent(input$remove3,{
    removeUI(
      selector = paste0('#', 3)
    )
    inserted$val <- inserted$val[!inserted$val %in% 3]
  })    
  
  
  observeEvent(input$remove4,{
    removeUI(
      selector = paste0('#', 4)
    )
    inserted$val <- inserted$val[!inserted$val %in% 4]
  })  
  
  
  observeEvent(input$remove5,{
    removeUI(
      selector = paste0('#', 5)
    )
    inserted$val <- inserted$val[!inserted$val %in% 5]
  })    
  
  
  observeEvent(input$remove6,{
    removeUI(
      selector = paste0('#', 6)
    )
    inserted$val <- inserted$val[!inserted$val %in% 6]
  })   
  
  
  observeEvent(input$remove7,{
    removeUI(
      selector = paste0('#', 7)
    )
    inserted$val <- inserted$val[!inserted$val %in% 7]
  })    
  
  
  observeEvent(input$remove8,{
    removeUI(
      selector = paste0('#', 8)
    )
    inserted$val <- inserted$val[!inserted$val %in% 8]
  })  
  
  
  observeEvent(input$remove9,{
    removeUI(
      selector = paste0('#', 9)
    )
    inserted$val <- inserted$val[!inserted$val %in% 9]
  })    
  
  
  observeEvent(input$remove10,{
    removeUI(
      selector = paste0('#', 10)
    )
    inserted$val <- inserted$val[!inserted$val %in% 10]
  })   
  
  
  observeEvent(input$remove11,{
    removeUI(
      selector = paste0('#', 11)
    )
    inserted$val <- inserted$val[!inserted$val %in% 11]
  })    
  
  
  observeEvent(input$remove12,{
    removeUI(
      selector = paste0('#', 12)
    )
    inserted$val <- inserted$val[!inserted$val %in% 12]
  })   
  
  
  observeEvent(input$remove13,{
    removeUI(
      selector = paste0('#', 13)
    )
    inserted$val <- inserted$val[!inserted$val %in% 13]
  })    
  
  
  observeEvent(input$remove14,{
    removeUI(
      selector = paste0('#', 14)
    )
    inserted$val <- inserted$val[!inserted$val %in% 14]
  })  
  
  
  observeEvent(input$remove15,{
    removeUI(
      selector = paste0('#', 15)
    )
    inserted$val <- inserted$val[!inserted$val %in% 15]
  })    
  
  
  observeEvent(input$remove16,{
    removeUI(
      selector = paste0('#', 16)
    )
    inserted$val <- inserted$val[!inserted$val %in% 16]
  })   
  
  
  observeEvent(input$remove17,{
    removeUI(
      selector = paste0('#', 17)
    )
    inserted$val <- inserted$val[!inserted$val %in% 17]
  })    
  
  
  observeEvent(input$remove18,{
    removeUI(
      selector = paste0('#', 18)
    )
    inserted$val <- inserted$val[!inserted$val %in% 18]
  })  
  
  
  observeEvent(input$remove19,{
    removeUI(
      selector = paste0('#', 19)
    )
    inserted$val <- inserted$val[!inserted$val %in% 19]
  })    
  
  
  observeEvent(input$remove20,{
    removeUI(
      selector = paste0('#', 20)
    )
    inserted$val <- inserted$val[!inserted$val %in% 20]
  })     
  
  
  observeEvent(input$remove21,{
    removeUI(
      selector = paste0('#', 21)
    )
    inserted$val <- inserted$val[!inserted$val %in% 21]
  })    
  
  
  observeEvent(input$remove22,{
    removeUI(
      selector = paste0('#', 22)
    )
    inserted$val <- inserted$val[!inserted$val %in% 22]
  })   
  
  
  observeEvent(input$remove23,{
    removeUI(
      selector = paste0('#', 23)
    )
    inserted$val <- inserted$val[!inserted$val %in% 23]
  })    
  
  
  observeEvent(input$remove24,{
    removeUI(
      selector = paste0('#', 24)
    )
    inserted$val <- inserted$val[!inserted$val %in% 24]
  })  
  
  
  observeEvent(input$remove25,{
    removeUI(
      selector = paste0('#', 25)
    )
    inserted$val <- inserted$val[!inserted$val %in% 25]
  })    
  
  
  observeEvent(input$remove26,{
    removeUI(
      selector = paste0('#', 26)
    )
    inserted$val <- inserted$val[!inserted$val %in% 26]
  })   
  
  
  observeEvent(input$remove27,{
    removeUI(
      selector = paste0('#', 27)
    )
    inserted$val <- inserted$val[!inserted$val %in% 27]
  })    
  
  
  observeEvent(input$remove28,{
    removeUI(
      selector = paste0('#', 28)
    )
    inserted$val <- inserted$val[!inserted$val %in% 28]
  })  
  
  
  observeEvent(input$remove29,{
    removeUI(
      selector = paste0('#', 29)
    )
    inserted$val <- inserted$val[!inserted$val %in% 29]
  })    
  
  
  observeEvent(input$remove30,{
    removeUI(
      selector = paste0('#', 30)
    )
    inserted$val <- inserted$val[!inserted$val %in% 30]
  })    
  
  
  observeEvent(input$remove31,{
    removeUI(
      selector = paste0('#', 31)
    )
    inserted$val <- inserted$val[!inserted$val %in% 31]
  })    
  
  
  observeEvent(input$remove32,{
    removeUI(
      selector = paste0('#', 32)
    )
    inserted$val <- inserted$val[!inserted$val %in% 32]
  })   
  
  
  observeEvent(input$remove33,{
    removeUI(
      selector = paste0('#', 33)
    )
    inserted$val <- inserted$val[!inserted$val %in% 33]
  })    
  
  
  observeEvent(input$remove34,{
    removeUI(
      selector = paste0('#', 34)
    )
    inserted$val <- inserted$val[!inserted$val %in% 34]
  })  
  
  
  observeEvent(input$remove35,{
    removeUI(
      selector = paste0('#', 35)
    )
    inserted$val <- inserted$val[!inserted$val %in% 35]
  })    
  
  
  observeEvent(input$remove36,{
    removeUI(
      selector = paste0('#', 36)
    )
    inserted$val <- inserted$val[!inserted$val %in% 36]
  })   
  
  
  observeEvent(input$remove37,{
    removeUI(
      selector = paste0('#', 37)
    )
    inserted$val <- inserted$val[!inserted$val %in% 37]
  })    
  
  
  observeEvent(input$remove38,{
    removeUI(
      selector = paste0('#', 38)
    )
    inserted$val <- inserted$val[!inserted$val %in% 38]
  })  
  
  
  observeEvent(input$remove39,{
    removeUI(
      selector = paste0('#', 39)
    )
    inserted$val <- inserted$val[!inserted$val %in% 39]
  })    
  
  
  observeEvent(input$remove40,{
    removeUI(
      selector = paste0('#', 40)
    )
    inserted$val <- inserted$val[!inserted$val %in% 40]
  })    
  
  
  observeEvent(input$remove41,{
    removeUI(
      selector = paste0('#', 41)
    )
    inserted$val <- inserted$val[!inserted$val %in% 41]
  })    
  
  
  observeEvent(input$remove42,{
    removeUI(
      selector = paste0('#', 42)
    )
    inserted$val <- inserted$val[!inserted$val %in% 42]
  })   
  
  
  observeEvent(input$remove43,{
    removeUI(
      selector = paste0('#', 43)
    )
    inserted$val <- inserted$val[!inserted$val %in% 43]
  })    
  
  
  observeEvent(input$remove44,{
    removeUI(
      selector = paste0('#', 44)
    )
    inserted$val <- inserted$val[!inserted$val %in% 44]
  })  
  
  
  observeEvent(input$remove45,{
    removeUI(
      selector = paste0('#', 45)
    )
    inserted$val <- inserted$val[!inserted$val %in% 45]
  })    
  
  
  observeEvent(input$remove46,{
    removeUI(
      selector = paste0('#', 46)
    )
    inserted$val <- inserted$val[!inserted$val %in% 46]
  })   
  
  
  observeEvent(input$remove47,{
    removeUI(
      selector = paste0('#', 47)
    )
    inserted$val <- inserted$val[!inserted$val %in% 47]
  })    
  
  
  observeEvent(input$remove48,{
    removeUI(
      selector = paste0('#', 48)
    )
    inserted$val <- inserted$val[!inserted$val %in% 48]
  })  
  
  
  observeEvent(input$remove49,{
    removeUI(
      selector = paste0('#', 49)
    )
    inserted$val <- inserted$val[!inserted$val %in% 49]
  })    
  
  
  observeEvent(input$remove50,{
    removeUI(
      selector = paste0('#', 50)
    )
    inserted$val <- inserted$val[!inserted$val %in% 50]
  })   
  
  
  observeEvent(input$remove51,{
    removeUI(
      selector = paste0('#', 51)
    )
    inserted$val <- inserted$val[!inserted$val %in% 51]
  })    
  
  
  observeEvent(input$remove52,{
    removeUI(
      selector = paste0('#', 52)
    )
    inserted$val <- inserted$val[!inserted$val %in% 52]
  })   
  
  
  observeEvent(input$remove53,{
    removeUI(
      selector = paste0('#', 53)
    )
    inserted$val <- inserted$val[!inserted$val %in% 53]
  })    
  
  
  observeEvent(input$remove54,{
    removeUI(
      selector = paste0('#', 54)
    )
    inserted$val <- inserted$val[!inserted$val %in% 54]
  })  
  
  
  observeEvent(input$remove55,{
    removeUI(
      selector = paste0('#', 55)
    )
    inserted$val <- inserted$val[!inserted$val %in% 55]
  })    
  
  
  observeEvent(input$remove56,{
    removeUI(
      selector = paste0('#', 56)
    )
    inserted$val <- inserted$val[!inserted$val %in% 56]
  })   
  
  
  observeEvent(input$remove57,{
    removeUI(
      selector = paste0('#', 57)
    )
    inserted$val <- inserted$val[!inserted$val %in% 57]
  })    
  
  
  observeEvent(input$remove58,{
    removeUI(
      selector = paste0('#', 58)
    )
    inserted$val <- inserted$val[!inserted$val %in% 58]
  })  
  
  
  observeEvent(input$remove59,{
    removeUI(
      selector = paste0('#', 59)
    )
    inserted$val <- inserted$val[!inserted$val %in% 59]
  })    
  
  
  observeEvent(input$remove60,{
    removeUI(
      selector = paste0('#', 60)
    )
    inserted$val <- inserted$val[!inserted$val %in% 60]
  })     
  
  
  observeEvent(input$remove61,{
    removeUI(
      selector = paste0('#', 61)
    )
    inserted$val <- inserted$val[!inserted$val %in% 61]
  })    
  
  
  observeEvent(input$remove62,{
    removeUI(
      selector = paste0('#', 62)
    )
    inserted$val <- inserted$val[!inserted$val %in% 62]
  })   
  
  
  observeEvent(input$remove63,{
    removeUI(
      selector = paste0('#', 63)
    )
    inserted$val <- inserted$val[!inserted$val %in% 63]
  })    
  
  
  observeEvent(input$remove64,{
    removeUI(
      selector = paste0('#', 64)
    )
    inserted$val <- inserted$val[!inserted$val %in% 64]
  })  
  
  
  observeEvent(input$remove65,{
    removeUI(
      selector = paste0('#', 65)
    )
    inserted$val <- inserted$val[!inserted$val %in% 65]
  })    
  
  
  observeEvent(input$remove66,{
    removeUI(
      selector = paste0('#', 66)
    )
    inserted$val <- inserted$val[!inserted$val %in% 66]
  })   
  
  
  observeEvent(input$remove67,{
    removeUI(
      selector = paste0('#', 67)
    )
    inserted$val <- inserted$val[!inserted$val %in% 67]
  })    
  
  
  observeEvent(input$remove68,{
    removeUI(
      selector = paste0('#', 68)
    )
    inserted$val <- inserted$val[!inserted$val %in% 68]
  })  
  
  
  observeEvent(input$remove69,{
    removeUI(
      selector = paste0('#', 69)
    )
    inserted$val <- inserted$val[!inserted$val %in% 69]
  })    
  
  
  observeEvent(input$remove70,{
    removeUI(
      selector = paste0('#', 70)
    )
    inserted$val <- inserted$val[!inserted$val %in% 70]
  })   
  
  
  observeEvent(input$remove71,{
    removeUI(
      selector = paste0('#', 71)
    )
    inserted$val <- inserted$val[!inserted$val %in% 71]
  })    
  
  
  observeEvent(input$remove72,{
    removeUI(
      selector = paste0('#', 72)
    )
    inserted$val <- inserted$val[!inserted$val %in% 72]
  })   
  
  
  observeEvent(input$remove73,{
    removeUI(
      selector = paste0('#', 73)
    )
    inserted$val <- inserted$val[!inserted$val %in% 73]
  })    
  
  
  observeEvent(input$remove74,{
    removeUI(
      selector = paste0('#', 74)
    )
    inserted$val <- inserted$val[!inserted$val %in% 74]
  })  
  
  
  observeEvent(input$remove75,{
    removeUI(
      selector = paste0('#', 75)
    )
    inserted$val <- inserted$val[!inserted$val %in% 75]
  })    
  
  
  observeEvent(input$remove76,{
    removeUI(
      selector = paste0('#', 76)
    )
    inserted$val <- inserted$val[!inserted$val %in% 76]
  })   
  
  
  observeEvent(input$remove77,{
    removeUI(
      selector = paste0('#', 77)
    )
    inserted$val <- inserted$val[!inserted$val %in% 77]
  })    
  
  
  observeEvent(input$remove78,{
    removeUI(
      selector = paste0('#', 78)
    )
    inserted$val <- inserted$val[!inserted$val %in% 78]
  })  
  
  
  observeEvent(input$remove79,{
    removeUI(
      selector = paste0('#', 79)
    )
    inserted$val <- inserted$val[!inserted$val %in% 79]
  })    
  
  
  observeEvent(input$remove80,{
    removeUI(
      selector = paste0('#', 80)
    )
    inserted$val <- inserted$val[!inserted$val %in% 80]
  })   
  
  
  observeEvent(input$remove81,{
    removeUI(
      selector = paste0('#', 81)
    )
    inserted$val <- inserted$val[!inserted$val %in% 81]
  })    
  
  
  observeEvent(input$remove82,{
    removeUI(
      selector = paste0('#', 82)
    )
    inserted$val <- inserted$val[!inserted$val %in% 82]
  })   
  
  
  observeEvent(input$remove83,{
    removeUI(
      selector = paste0('#', 83)
    )
    inserted$val <- inserted$val[!inserted$val %in% 83]
  })    
  
  
  observeEvent(input$remove84,{
    removeUI(
      selector = paste0('#', 84)
    )
    inserted$val <- inserted$val[!inserted$val %in% 84]
  })  
  
  
  observeEvent(input$remove85,{
    removeUI(
      selector = paste0('#', 85)
    )
    inserted$val <- inserted$val[!inserted$val %in% 85]
  })    
  
  
  observeEvent(input$remove86,{
    removeUI(
      selector = paste0('#', 86)
    )
    inserted$val <- inserted$val[!inserted$val %in% 86]
  })   
  
  
  observeEvent(input$remove87,{
    removeUI(
      selector = paste0('#', 87)
    )
    inserted$val <- inserted$val[!inserted$val %in% 87]
  })    
  
  
  observeEvent(input$remove88,{
    removeUI(
      selector = paste0('#', 88)
    )
    inserted$val <- inserted$val[!inserted$val %in% 88]
  })  
  
  
  observeEvent(input$remove89,{
    removeUI(
      selector = paste0('#', 89)
    )
    inserted$val <- inserted$val[!inserted$val %in% 89]
  })    
  
  
  observeEvent(input$remove90,{
    removeUI(
      selector = paste0('#', 90)
    )
    inserted$val <- inserted$val[!inserted$val %in% 90]
  })   
  

  observeEvent(input$remove91,{
    removeUI(
      selector = paste0('#', 91)
    )
    inserted$val <- inserted$val[!inserted$val %in% 91]
  })    
  
  
  observeEvent(input$remove92,{
    removeUI(
      selector = paste0('#', 92)
    )
    inserted$val <- inserted$val[!inserted$val %in% 92]
  })   
  
  
  observeEvent(input$remove93,{
    removeUI(
      selector = paste0('#', 93)
    )
    inserted$val <- inserted$val[!inserted$val %in% 93]
  })    
  
  
  observeEvent(input$remove94,{
    removeUI(
      selector = paste0('#', 94)
    )
    inserted$val <- inserted$val[!inserted$val %in% 94]
  })  
  
  
  observeEvent(input$remove95,{
    removeUI(
      selector = paste0('#', 95)
    )
    inserted$val <- inserted$val[!inserted$val %in% 95]
  })    
  
  
  observeEvent(input$remove96,{
    removeUI(
      selector = paste0('#', 96)
    )
    inserted$val <- inserted$val[!inserted$val %in% 96]
  })   
  
  
  observeEvent(input$remove97,{
    removeUI(
      selector = paste0('#', 97)
    )
    inserted$val <- inserted$val[!inserted$val %in% 97]
  })    
  
  
  observeEvent(input$remove98,{
    removeUI(
      selector = paste0('#', 98)
    )
    inserted$val <- inserted$val[!inserted$val %in% 98]
  })  
  
  
  observeEvent(input$remove99,{
    removeUI(
      selector = paste0('#', 99)
    )
    inserted$val <- inserted$val[!inserted$val %in% 99]
  })    
  
  
  observeEvent(input$remove100,{
    removeUI(
      selector = paste0('#', 100)
    )
    inserted$val <- inserted$val[!inserted$val %in% 100]
  })   
  
  
  ####################################END OF REMOVE UNWANTED ROWS##################################################### 
###############################################################################################################  
  
  
  
  
  
  

############################################### CREATE METAANALYSIS PLOT#########################################
#################################################################################################################
  output$metaanalysis <- renderPlot({
  
    
## Collect the inputs
## Allow 100 inputs to allow for multiple changes in studies inputs and multiple studies
    
    # Treatments
    Treatments <- c(input$Treatment1, input$Treatment2, input$Treatment3, input$Treatment4, input$Treatment5, 
              input$Treatment6, input$Treatment7, input$Treatment8, input$Treatment9, input$Treatment10, 
              input$Treatment11, input$Treatment12, input$Treatment13, input$Treatment14, input$Treatment15,
              input$Treatment16, input$Treatment17, input$Treatment18, input$Treatment19, input$Treatment20,
              input$Treatment21, input$Treatment22, input$Treatment23, input$Treatment24, input$Treatment25,
              input$Treatment26, input$Treatment27, input$Treatment28, input$Treatment29, input$Treatment30,
              input$Treatment31, input$Treatment32, input$Treatment33, input$Treatment34, input$Treatment35,
              input$Treatment36, input$Treatment37, input$Treatment38, input$Treatment39, input$Treatment40,
              input$Treatment41, input$Treatment42, input$Treatment43, input$Treatment44, input$Treatment45,
              input$Treatment46, input$Treatment47, input$Treatment48, input$Treatment49, input$Treatment50,
              input$Treatment51, input$Treatment52, input$Treatment53, input$Treatment54, input$Treatment55,
              input$Treatment56, input$Treatment57, input$Treatment58, input$Treatment59, input$Treatment60,
              input$Treatment61, input$Treatment62, input$Treatment63, input$Treatment64, input$Treatment65,
              input$Treatment66, input$Treatment67, input$Treatment68, input$Treatment69, input$Treatment70,
              input$Treatment71, input$Treatment72, input$Treatment73, input$Treatment74, input$Treatment75,
              input$Treatment76, input$Treatment77, input$Treatment78, input$Treatment79, input$Treatment80,
              input$Treatment81, input$Treatment82, input$Treatment83, input$Treatment84, input$Treatment85,
              input$Treatment86, input$Treatment87, input$Treatment88, input$Treatment89, input$Treatment90,
              input$Treatment91, input$Treatment92, input$Treatment93, input$Treatment94, input$Treatment95,
              input$Treatment96, input$Treatment97, input$Treatment98, input$Treatment99, input$Treatment100)
    # Consider only those treatments from studies that have not been deleted and are in the interactive reactivevalues list 
    Treatments <- Treatments[inserted$val]
    
    
    # Studies
    studies <- c(input$studyname1, input$studyname2, input$studyname3, input$studyname4, input$studyname5, 
                 input$studyname6, input$studyname7, input$studyname8, input$studyname9, input$studyname10, 
                 input$studyname11, input$studyname12, input$studyname13, input$studyname14, input$studyname15,
                 input$studyname16, input$studyname17, input$studyname18, input$studyname19, input$studyname20,
                 input$studyname21, input$studyname22, input$studyname23, input$studyname24, input$studyname25,
                 input$studyname26, input$studyname27, input$studyname28, input$studyname29, input$studyname30,
                 input$studyname31, input$studyname32, input$studyname33, input$studyname34, input$studyname35,
                 input$studyname36, input$studyname37, input$studyname38, input$studyname39, input$studyname40,
                 input$studyname41, input$studyname42, input$studyname43, input$studyname44, input$studyname45,
                 input$studyname46, input$studyname47, input$studyname48, input$studyname49, input$studyname50,
                 input$studyname51, input$studyname52, input$studyname53, input$studyname54, input$studyname55,
                 input$studyname56, input$studyname57, input$studyname58, input$studyname59, input$studyname60,
                 input$studyname61, input$studyname62, input$studyname63, input$studyname64, input$studyname65,
                 input$studyname66, input$studyname67, input$studyname68, input$studyname69, input$studyname70,
                 input$studyname71, input$studyname72, input$studyname73, input$studyname74, input$studyname75,
                 input$studyname76, input$studyname77, input$studyname78, input$studyname79, input$studyname80,
                 input$studyname81, input$studyname82, input$studyname83, input$studyname84, input$studyname85,
                 input$studyname86, input$studyname87, input$studyname88, input$studyname89, input$studyname90,
                 input$studyname91, input$studyname92, input$studyname93, input$studyname94, input$studyname95,
                 input$studyname96, input$studyname97, input$studyname98, input$studyname99, input$studyname100)
    # Consider only those studies from studies that have not been deleted and are in the interactive reactivevalues list
    studies <- studies[inserted$val]
    
    
    # Number of patients who responded to the medication
    responded <- c(input$nresponded1, input$nresponded2, input$nresponded3, input$nresponded4, input$nresponded5, 
                   input$nresponded6, input$nresponded7, input$nresponded8, input$nresponded9, input$nresponded10, 
                   input$nresponded11, input$nresponded12, input$nresponded13, input$nresponded14, input$nresponded15,
                   input$nresponded16, input$nresponded17, input$nresponded18, input$nresponded19, input$nresponded20,
                   input$nresponded21, input$nresponded22, input$nresponded23, input$nresponded24, input$nresponded25,
                   input$nresponded26, input$nresponded27, input$nresponded28, input$nresponded29, input$nresponded30,
                   input$nresponded31, input$nresponded32, input$nresponded33, input$nresponded34, input$nresponded35,
                   input$nresponded36, input$nresponded37, input$nresponded38, input$nresponded39, input$nresponded40,
                   input$nresponded41, input$nresponded42, input$nresponded43, input$nresponded44, input$nresponded45,
                   input$nresponded46, input$nresponded47, input$nresponded48, input$nresponded49, input$nresponded50,
                   input$nresponded51, input$nresponded52, input$nresponded53, input$nresponded54, input$nresponded55,
                   input$nresponded56, input$nresponded57, input$nresponded58, input$nresponded59, input$nresponded60,
                   input$nresponded61, input$nresponded62, input$nresponded63, input$nresponded64, input$nresponded65,
                   input$nresponded66, input$nresponded67, input$nresponded68, input$nresponded69, input$nresponded70,
                   input$nresponded71, input$nresponded72, input$nresponded73, input$nresponded74, input$nresponded75,
                   input$nresponded76, input$nresponded77, input$nresponded78, input$nresponded79, input$nresponded80,
                   input$nresponded81, input$nresponded82, input$nresponded83, input$nresponded84, input$nresponded85,
                   input$nresponded86, input$nresponded87, input$nresponded88, input$nresponded89, input$nresponded90,
                   input$nresponded91, input$nresponded92, input$nresponded93, input$nresponded94, input$nresponded95,
                   input$nresponded96, input$nresponded97, input$nresponded98, input$nresponded99, input$nresponded100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    responded <- responded[inserted$val]
    
    
    # Total number of patients in the study
    total <- c(input$ntotal1, input$ntotal2, input$ntotal3, input$ntotal4, input$ntotal5, 
               input$ntotal6, input$ntotal7, input$ntotal8, input$ntotal9, input$ntotal10, 
               input$ntotal11, input$ntotal12, input$ntotal13, input$ntotal14, input$ntotal15,
               input$ntotal16, input$ntotal17, input$ntotal18, input$ntotal19, input$ntotal20,
               input$ntotal21, input$ntotal22, input$ntotal23, input$ntotal24, input$ntotal25,
               input$ntotal26, input$ntotal27, input$ntotal28, input$ntotal29, input$ntotal30,
               input$ntotal31, input$ntotal32, input$ntotal33, input$ntotal34, input$ntotal35,
               input$ntotal36, input$ntotal37, input$ntotal38, input$ntotal39, input$ntotal40,
               input$ntotal41, input$ntotal42, input$ntotal43, input$ntotal44, input$ntotal45,
               input$ntotal46, input$ntotal47, input$ntotal48, input$ntotal49, input$ntotal50,
               input$ntotal51, input$ntotal52, input$ntotal53, input$ntotal54, input$ntotal55,
               input$ntotal56, input$ntotal57, input$ntotal58, input$ntotal59, input$ntotal60,
               input$ntotal61, input$ntotal62, input$ntotal63, input$ntotal64, input$ntotal65,
               input$ntotal66, input$ntotal67, input$ntotal68, input$ntotal69, input$ntotal70,
               input$ntotal71, input$ntotal72, input$ntotal73, input$ntotal74, input$ntotal75,
               input$ntotal76, input$ntotal77, input$ntotal78, input$ntotal79, input$ntotal80,
               input$ntotal81, input$ntotal82, input$ntotal83, input$ntotal84, input$ntotal85,
               input$ntotal86, input$ntotal87, input$ntotal88, input$ntotal89, input$ntotal90,
               input$ntotal91, input$ntotal92, input$ntotal93, input$ntotal94, input$ntotal95,
               input$ntotal96, input$ntotal97, input$ntotal98, input$ntotal99, input$ntotal100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    total <- total[inserted$val]
    
    # Create dataframe with the data
    data_metaanalysis <- data.frame(Treatments, studies, responded, total)
    
    
    ## If there is no adjustment for publication bias, create the regular forest plot
    if (input$checkbox_publication_bias==FALSE) {  
    
    # Collect the data for the metaanalysis in a metaprop object    
    dataformetaanalysis <- metaprop(
      # Patients who responded
      event = as.numeric(as.character(data_metaanalysis$responded)),
      # Total number of patients in the study
      n = as.numeric(as.character(data_metaanalysis$total)),
      # Study names
      studlab = data_metaanalysis$studies,
      # Classification variable (type of AED)
      byvar = data_metaanalysis$Treatments,                     
      method="Inverse"
    )
    
    # Create the forest plot
    forestplot <- forest(dataformetaanalysis, comb.fixed = FALSE, lty.random = 2, lty.fixed = 0, 
                    xlim = c(0, 1), lwd = 1.75, col.study = "navy", col.square = "gray", col.square.lines = "navy",
                    col.diamond.random = "red", col.diamond.lines.random = "red",
                    print.I2 = TRUE, print.I2.ci = TRUE, print.tau2 = FALSE, print.pval.Q = FALSE,
                    fontsize = 16, fs.heading = 20, fs.hetstat = 16, fs.axis = 16, fs.test.overall = 16,
                    fs.random = 20, fs.smlab = 20, ff.study.labels =  "bold", 
                    ff.axis = "bold", squaresize = 1.2, 
                    backtransf = TRUE, test.overall.random = TRUE, 
                    leftcols = c("studlab", "effect", "ci"), rightcols = FALSE,
                    just = "right", digits = 2, bylab = "MEDICATION",
                    print.byvar = FALSE, col.by = "blue", overall = FALSE, overall.hetstat = FALSE,
                    test.subgroup.random = TRUE, fs.test.subgroup.random = 16)

    # Render the forest plot
    forestplot
    
    
    ## If there is adjustment for publication bias, create the forest plot with imputted studies
    } else {
      
      # Select only the data for ACTH
      data_metaanalysis_ACTH <- data_metaanalysis[Treatments=="ACTH", ]
      
      # Collect the data for the metaanalysis for ACTH in a metaprop object    
      dataformetaanalysisACTH <- metaprop(
        # Patients who responded
        event = as.numeric(as.character(data_metaanalysis_ACTH$responded)),
        # Total number of patients in the study
        n = as.numeric(as.character(data_metaanalysis_ACTH$total)),
        # Study names
        studlab = data_metaanalysis_ACTH$studies,
        # Classification variable (type of AED)
        byvar = data_metaanalysis_ACTH$Treatments,                     
        method="Inverse"
      )
      
      # Trim-and-fill the data for ACTH
      ACTH_trimandfill <- trimfill(dataformetaanalysisACTH, ma.fixed = TRUE, comb.random = TRUE)
      
      
      
      # Select only the data for oral steroids
      data_metaanalysis_PRD <- data_metaanalysis[Treatments=="Oral steroids", ]
      
      # Collect the data for the metaanalysis for oral steroids in a metaprop object    
      dataformetaanalysisPRD <- metaprop(
        # Patients who responded
        event = as.numeric(as.character(data_metaanalysis_PRD$responded)),
        # Total number of patients in the study
        n = as.numeric(as.character(data_metaanalysis_PRD$total)),
        # Study names
        studlab = data_metaanalysis_PRD$studies,
        # Classification variable (type of AED)
        byvar = data_metaanalysis_PRD$Treatments,                     
        method="Inverse"
      )
      
      # Trim-and-fill the data for oral steroids
      PRD_trimandfill <- trimfill(dataformetaanalysisPRD, ma.fixed = TRUE, comb.random = TRUE)
      
      
      # Meta-analysis considering subgroups by groups: ACTH and oral steroids
      trimmedandfilledmetaanalysis <- metagen(TE = c(ACTH_trimandfill$TE,                             ### ACTH
                                                     PRD_trimandfill$TE),                                     ### Oral steroids                                      
                                              
                                              seTE = c(              ACTH_trimandfill$seTE,                   ### ACTH
                                                                     PRD_trimandfill$seTE),                   ### Oral steroids                                         
                                              
                                              studlab = c(ACTH_trimandfill$studlab,                           ### ACTH
                                                          PRD_trimandfill$studlab),                           ### Oral steroids
                                              
                                              byvar = c(
                                                rep("ACTH", length(ACTH_trimandfill$studlab)),         ### ACTH
                                                rep("Oral steroids", length(PRD_trimandfill$studlab))   ### Oral steroids
                                              ),         
                                              sm = "PLOGIT"
      )
      
      # Create the forest plot
      forestplot <- forest(trimmedandfilledmetaanalysis, comb.fixed = FALSE, lty.random = 2, lty.fixed = 0, 
                           xlim = c(0, 1), lwd = 1.75, col.study = "navy", col.square = "gray", col.square.lines = "navy",
                           col.diamond.random = "red", col.diamond.lines.random = "red",
                           print.I2 = TRUE, print.I2.ci = TRUE, print.tau2 = FALSE, print.pval.Q = FALSE,
                           fontsize = 16, fs.heading = 20, fs.hetstat = 16, fs.axis = 16, fs.test.overall = 16,
                           fs.random = 20, fs.smlab = 20, ff.study.labels =  "bold", 
                           ff.axis = "bold", squaresize = 1.2, 
                           backtransf = TRUE, test.overall.random = TRUE, 
                           leftcols = c("studlab", "effect", "ci"), rightcols = FALSE,
                           just = "right", digits = 2, bylab = "MEDICATION",
                           print.byvar = FALSE, col.by = "blue", overall = FALSE, overall.hetstat = FALSE,
                           test.subgroup.random = TRUE, fs.test.subgroup.random = 16)
      
      # Render the forest plot
      forestplot
    }
    
  }, width = 700, height = 800)
  
  
  
  output$publicationbiasACTH <- renderPlot({
    
    
    ## Collect the inputs
    ## Allow 100 inputs to allow for multiple changes in studies inputs and multiple studies
    
    # Treatments
    Treatments <- c(input$Treatment1, input$Treatment2, input$Treatment3, input$Treatment4, input$Treatment5, 
                    input$Treatment6, input$Treatment7, input$Treatment8, input$Treatment9, input$Treatment10, 
                    input$Treatment11, input$Treatment12, input$Treatment13, input$Treatment14, input$Treatment15,
                    input$Treatment16, input$Treatment17, input$Treatment18, input$Treatment19, input$Treatment20,
                    input$Treatment21, input$Treatment22, input$Treatment23, input$Treatment24, input$Treatment25,
                    input$Treatment26, input$Treatment27, input$Treatment28, input$Treatment29, input$Treatment30,
                    input$Treatment31, input$Treatment32, input$Treatment33, input$Treatment34, input$Treatment35,
                    input$Treatment36, input$Treatment37, input$Treatment38, input$Treatment39, input$Treatment40,
                    input$Treatment41, input$Treatment42, input$Treatment43, input$Treatment44, input$Treatment45,
                    input$Treatment46, input$Treatment47, input$Treatment48, input$Treatment49, input$Treatment50,
                    input$Treatment51, input$Treatment52, input$Treatment53, input$Treatment54, input$Treatment55,
                    input$Treatment56, input$Treatment57, input$Treatment58, input$Treatment59, input$Treatment60,
                    input$Treatment61, input$Treatment62, input$Treatment63, input$Treatment64, input$Treatment65,
                    input$Treatment66, input$Treatment67, input$Treatment68, input$Treatment69, input$Treatment70,
                    input$Treatment71, input$Treatment72, input$Treatment73, input$Treatment74, input$Treatment75,
                    input$Treatment76, input$Treatment77, input$Treatment78, input$Treatment79, input$Treatment80,
                    input$Treatment81, input$Treatment82, input$Treatment83, input$Treatment84, input$Treatment85,
                    input$Treatment86, input$Treatment87, input$Treatment88, input$Treatment89, input$Treatment90,
                    input$Treatment91, input$Treatment92, input$Treatment93, input$Treatment94, input$Treatment95,
                    input$Treatment96, input$Treatment97, input$Treatment98, input$Treatment99, input$Treatment100)
    # Consider only those treatments from studies that have not been deleted and are in the interactive reactivevalues list 
    Treatments <- Treatments[inserted$val]
    
    
    
    # Studies
    studies <- c(input$studyname1, input$studyname2, input$studyname3, input$studyname4, input$studyname5, 
                 input$studyname6, input$studyname7, input$studyname8, input$studyname9, input$studyname10, 
                 input$studyname11, input$studyname12, input$studyname13, input$studyname14, input$studyname15,
                 input$studyname16, input$studyname17, input$studyname18, input$studyname19, input$studyname20,
                 input$studyname21, input$studyname22, input$studyname23, input$studyname24, input$studyname25,
                 input$studyname26, input$studyname27, input$studyname28, input$studyname29, input$studyname30,
                 input$studyname31, input$studyname32, input$studyname33, input$studyname34, input$studyname35,
                 input$studyname36, input$studyname37, input$studyname38, input$studyname39, input$studyname40,
                 input$studyname41, input$studyname42, input$studyname43, input$studyname44, input$studyname45,
                 input$studyname46, input$studyname47, input$studyname48, input$studyname49, input$studyname50,
                 input$studyname51, input$studyname52, input$studyname53, input$studyname54, input$studyname55,
                 input$studyname56, input$studyname57, input$studyname58, input$studyname59, input$studyname60,
                 input$studyname61, input$studyname62, input$studyname63, input$studyname64, input$studyname65,
                 input$studyname66, input$studyname67, input$studyname68, input$studyname69, input$studyname70,
                 input$studyname71, input$studyname72, input$studyname73, input$studyname74, input$studyname75,
                 input$studyname76, input$studyname77, input$studyname78, input$studyname79, input$studyname80,
                 input$studyname81, input$studyname82, input$studyname83, input$studyname84, input$studyname85,
                 input$studyname86, input$studyname87, input$studyname88, input$studyname89, input$studyname90,
                 input$studyname91, input$studyname92, input$studyname93, input$studyname94, input$studyname95,
                 input$studyname96, input$studyname97, input$studyname98, input$studyname99, input$studyname100)
    # Consider only those studies from studies that have not been deleted and are in the interactive reactivevalues list
    studies <- studies[inserted$val]
    
    
    # Number of patients who responded to the medication
    responded <- c(input$nresponded1, input$nresponded2, input$nresponded3, input$nresponded4, input$nresponded5, 
                   input$nresponded6, input$nresponded7, input$nresponded8, input$nresponded9, input$nresponded10, 
                   input$nresponded11, input$nresponded12, input$nresponded13, input$nresponded14, input$nresponded15,
                   input$nresponded16, input$nresponded17, input$nresponded18, input$nresponded19, input$nresponded20,
                   input$nresponded21, input$nresponded22, input$nresponded23, input$nresponded24, input$nresponded25,
                   input$nresponded26, input$nresponded27, input$nresponded28, input$nresponded29, input$nresponded30,
                   input$nresponded31, input$nresponded32, input$nresponded33, input$nresponded34, input$nresponded35,
                   input$nresponded36, input$nresponded37, input$nresponded38, input$nresponded39, input$nresponded40,
                   input$nresponded41, input$nresponded42, input$nresponded43, input$nresponded44, input$nresponded45,
                   input$nresponded46, input$nresponded47, input$nresponded48, input$nresponded49, input$nresponded50,
                   input$nresponded51, input$nresponded52, input$nresponded53, input$nresponded54, input$nresponded55,
                   input$nresponded56, input$nresponded57, input$nresponded58, input$nresponded59, input$nresponded60,
                   input$nresponded61, input$nresponded62, input$nresponded63, input$nresponded64, input$nresponded65,
                   input$nresponded66, input$nresponded67, input$nresponded68, input$nresponded69, input$nresponded70,
                   input$nresponded71, input$nresponded72, input$nresponded73, input$nresponded74, input$nresponded75,
                   input$nresponded76, input$nresponded77, input$nresponded78, input$nresponded79, input$nresponded80,
                   input$nresponded81, input$nresponded82, input$nresponded83, input$nresponded84, input$nresponded85,
                   input$nresponded86, input$nresponded87, input$nresponded88, input$nresponded89, input$nresponded90,
                   input$nresponded91, input$nresponded92, input$nresponded93, input$nresponded94, input$nresponded95,
                   input$nresponded96, input$nresponded97, input$nresponded98, input$nresponded99, input$nresponded100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    responded <- responded[inserted$val]
    
    
    # Total number of patients in the study
    total <- c(input$ntotal1, input$ntotal2, input$ntotal3, input$ntotal4, input$ntotal5, 
               input$ntotal6, input$ntotal7, input$ntotal8, input$ntotal9, input$ntotal10, 
               input$ntotal11, input$ntotal12, input$ntotal13, input$ntotal14, input$ntotal15,
               input$ntotal16, input$ntotal17, input$ntotal18, input$ntotal19, input$ntotal20,
               input$ntotal21, input$ntotal22, input$ntotal23, input$ntotal24, input$ntotal25,
               input$ntotal26, input$ntotal27, input$ntotal28, input$ntotal29, input$ntotal30,
               input$ntotal31, input$ntotal32, input$ntotal33, input$ntotal34, input$ntotal35,
               input$ntotal36, input$ntotal37, input$ntotal38, input$ntotal39, input$ntotal40,
               input$ntotal41, input$ntotal42, input$ntotal43, input$ntotal44, input$ntotal45,
               input$ntotal46, input$ntotal47, input$ntotal48, input$ntotal49, input$ntotal50,
               input$ntotal51, input$ntotal52, input$ntotal53, input$ntotal54, input$ntotal55,
               input$ntotal56, input$ntotal57, input$ntotal58, input$ntotal59, input$ntotal60,
               input$ntotal61, input$ntotal62, input$ntotal63, input$ntotal64, input$ntotal65,
               input$ntotal66, input$ntotal67, input$ntotal68, input$ntotal69, input$ntotal70,
               input$ntotal71, input$ntotal72, input$ntotal73, input$ntotal74, input$ntotal75,
               input$ntotal76, input$ntotal77, input$ntotal78, input$ntotal79, input$ntotal80,
               input$ntotal81, input$ntotal82, input$ntotal83, input$ntotal84, input$ntotal85,
               input$ntotal86, input$ntotal87, input$ntotal88, input$ntotal89, input$ntotal90,
               input$ntotal91, input$ntotal92, input$ntotal93, input$ntotal94, input$ntotal95,
               input$ntotal96, input$ntotal97, input$ntotal98, input$ntotal99, input$ntotal100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    total <- total[inserted$val]
    
    # Save variables in dataframe
    data_metaanalysis <- data.frame(Treatments, studies, responded, total)
        
    # Select only the data for ACTH
    data_metaanalysis_ACTH <- data_metaanalysis[Treatments=="ACTH", ]

        
    ## If there is no adjustment for publication bias, create the regular forest plot
    if (input$checkbox_publication_bias==FALSE) {       
    
    # Collect the data for the metaanalysis in a metaprop object    
    dataformetaanalysisACTH <- metaprop(
      # Patients who responded
      event = as.numeric(as.character(data_metaanalysis_ACTH$responded)),
      # Total number of patients in the study
      n = as.numeric(as.character(data_metaanalysis_ACTH$total)),
      # Study names
      studlab = data_metaanalysis_ACTH$studies,
      # Classification variable (type of treatment)
      byvar = data_metaanalysis_ACTH$Treatments,                     
      method="Inverse"
    )
    
    # Create the publication bias plot
    publicationbiasplotACTH <- funnel(dataformetaanalysisACTH, comb.fixed = FALSE, comb.random = TRUE, 
                                  pch = 21, cex = 1.5,
                                  lty.random = 2, lwd.random = 2, bg = "navy", col = "navy",
                                  studlab = FALSE)
    
    
    # Render the publication bias plot
    publicationbiasplotACTH
    
    
    ## If there is adjustment for publication bias, create the forest plot with imputted studies
    } else {

      # Collect the data for the metaanalysis for ACTH in a metaprop object    
      dataformetaanalysisACTH <- metaprop(
        # Patients who responded
        event = as.numeric(as.character(data_metaanalysis_ACTH$responded)),
        # Total number of patients in the study
        n = as.numeric(as.character(data_metaanalysis_ACTH$total)),
        # Study names
        studlab = data_metaanalysis_ACTH$studies,
        # Classification variable (type of treatment)
        byvar = data_metaanalysis_ACTH$Treatments,                     
        method="Inverse"
      )
      
      # Trim-and-fill the data for ACTH
      ACTH_trimandfill <- trimfill(dataformetaanalysisACTH, ma.fixed = TRUE, comb.random = TRUE)
      
      # Create the publication bias plot
      publicationbiasplotACTH <- funnel(ACTH_trimandfill, comb.fixed = FALSE, comb.random = TRUE, 
                                        pch = 21, cex = 1.5,
                                        lty.random = 2, lwd.random = 2, 
                                        bg = c(rep("navy", length(dataformetaanalysisACTH$studlab)), 
                                        rep("red", length(ACTH_trimandfill$studlab)-length(dataformetaanalysisACTH$studlab))), 
                                        col = c(rep("navy", length(dataformetaanalysisACTH$studlab)), 
                                        rep("red", length(ACTH_trimandfill$studlab)-length(dataformetaanalysisACTH$studlab))),
                                        studlab = FALSE)
      
      
      # Render the publication bias plot
      publicationbiasplotACTH      
      
    }
    
  }, width = 400, height = 400) 
  
  
  
  output$publicationbiasPRD <- renderPlot({
    
    
    ## Collect the inputs
    ## Allow 100 inputs to allow for multiple changes in studies inputs and multiple studies
    
    # Treatments
    Treatments <- c(input$Treatment1, input$Treatment2, input$Treatment3, input$Treatment4, input$Treatment5, 
                    input$Treatment6, input$Treatment7, input$Treatment8, input$Treatment9, input$Treatment10, 
                    input$Treatment11, input$Treatment12, input$Treatment13, input$Treatment14, input$Treatment15,
                    input$Treatment16, input$Treatment17, input$Treatment18, input$Treatment19, input$Treatment20,
                    input$Treatment21, input$Treatment22, input$Treatment23, input$Treatment24, input$Treatment25,
                    input$Treatment26, input$Treatment27, input$Treatment28, input$Treatment29, input$Treatment30,
                    input$Treatment31, input$Treatment32, input$Treatment33, input$Treatment34, input$Treatment35,
                    input$Treatment36, input$Treatment37, input$Treatment38, input$Treatment39, input$Treatment40,
                    input$Treatment41, input$Treatment42, input$Treatment43, input$Treatment44, input$Treatment45,
                    input$Treatment46, input$Treatment47, input$Treatment48, input$Treatment49, input$Treatment50,
                    input$Treatment51, input$Treatment52, input$Treatment53, input$Treatment54, input$Treatment55,
                    input$Treatment56, input$Treatment57, input$Treatment58, input$Treatment59, input$Treatment60,
                    input$Treatment61, input$Treatment62, input$Treatment63, input$Treatment64, input$Treatment65,
                    input$Treatment66, input$Treatment67, input$Treatment68, input$Treatment69, input$Treatment70,
                    input$Treatment71, input$Treatment72, input$Treatment73, input$Treatment74, input$Treatment75,
                    input$Treatment76, input$Treatment77, input$Treatment78, input$Treatment79, input$Treatment80,
                    input$Treatment81, input$Treatment82, input$Treatment83, input$Treatment84, input$Treatment85,
                    input$Treatment86, input$Treatment87, input$Treatment88, input$Treatment89, input$Treatment90,
                    input$Treatment91, input$Treatment92, input$Treatment93, input$Treatment94, input$Treatment95,
                    input$Treatment96, input$Treatment97, input$Treatment98, input$Treatment99, input$Treatment100)
    # Consider only those treatments from studies that have not been deleted and are in the interactive reactivevalues list 
    Treatments <- Treatments[inserted$val]
    
    
    
    # Studies
    studies <- c(input$studyname1, input$studyname2, input$studyname3, input$studyname4, input$studyname5, 
                 input$studyname6, input$studyname7, input$studyname8, input$studyname9, input$studyname10, 
                 input$studyname11, input$studyname12, input$studyname13, input$studyname14, input$studyname15,
                 input$studyname16, input$studyname17, input$studyname18, input$studyname19, input$studyname20,
                 input$studyname21, input$studyname22, input$studyname23, input$studyname24, input$studyname25,
                 input$studyname26, input$studyname27, input$studyname28, input$studyname29, input$studyname30,
                 input$studyname31, input$studyname32, input$studyname33, input$studyname34, input$studyname35,
                 input$studyname36, input$studyname37, input$studyname38, input$studyname39, input$studyname40,
                 input$studyname41, input$studyname42, input$studyname43, input$studyname44, input$studyname45,
                 input$studyname46, input$studyname47, input$studyname48, input$studyname49, input$studyname50,
                 input$studyname51, input$studyname52, input$studyname53, input$studyname54, input$studyname55,
                 input$studyname56, input$studyname57, input$studyname58, input$studyname59, input$studyname60,
                 input$studyname61, input$studyname62, input$studyname63, input$studyname64, input$studyname65,
                 input$studyname66, input$studyname67, input$studyname68, input$studyname69, input$studyname70,
                 input$studyname71, input$studyname72, input$studyname73, input$studyname74, input$studyname75,
                 input$studyname76, input$studyname77, input$studyname78, input$studyname79, input$studyname80,
                 input$studyname81, input$studyname82, input$studyname83, input$studyname84, input$studyname85,
                 input$studyname86, input$studyname87, input$studyname88, input$studyname89, input$studyname90,
                 input$studyname91, input$studyname92, input$studyname93, input$studyname94, input$studyname95,
                 input$studyname96, input$studyname97, input$studyname98, input$studyname99, input$studyname100)
    # Consider only those studies from studies that have not been deleted and are in the interactive reactivevalues list
    studies <- studies[inserted$val]
    
    
    # Number of patients who responded to the medication
    responded <- c(input$nresponded1, input$nresponded2, input$nresponded3, input$nresponded4, input$nresponded5, 
                   input$nresponded6, input$nresponded7, input$nresponded8, input$nresponded9, input$nresponded10, 
                   input$nresponded11, input$nresponded12, input$nresponded13, input$nresponded14, input$nresponded15,
                   input$nresponded16, input$nresponded17, input$nresponded18, input$nresponded19, input$nresponded20,
                   input$nresponded21, input$nresponded22, input$nresponded23, input$nresponded24, input$nresponded25,
                   input$nresponded26, input$nresponded27, input$nresponded28, input$nresponded29, input$nresponded30,
                   input$nresponded31, input$nresponded32, input$nresponded33, input$nresponded34, input$nresponded35,
                   input$nresponded36, input$nresponded37, input$nresponded38, input$nresponded39, input$nresponded40,
                   input$nresponded41, input$nresponded42, input$nresponded43, input$nresponded44, input$nresponded45,
                   input$nresponded46, input$nresponded47, input$nresponded48, input$nresponded49, input$nresponded50,
                   input$nresponded51, input$nresponded52, input$nresponded53, input$nresponded54, input$nresponded55,
                   input$nresponded56, input$nresponded57, input$nresponded58, input$nresponded59, input$nresponded60,
                   input$nresponded61, input$nresponded62, input$nresponded63, input$nresponded64, input$nresponded65,
                   input$nresponded66, input$nresponded67, input$nresponded68, input$nresponded69, input$nresponded70,
                   input$nresponded71, input$nresponded72, input$nresponded73, input$nresponded74, input$nresponded75,
                   input$nresponded76, input$nresponded77, input$nresponded78, input$nresponded79, input$nresponded80,
                   input$nresponded81, input$nresponded82, input$nresponded83, input$nresponded84, input$nresponded85,
                   input$nresponded86, input$nresponded87, input$nresponded88, input$nresponded89, input$nresponded90,
                   input$nresponded91, input$nresponded92, input$nresponded93, input$nresponded94, input$nresponded95,
                   input$nresponded96, input$nresponded97, input$nresponded98, input$nresponded99, input$nresponded100)
    # Consider only those responders from studies that have not been deleted and are in the interactive reactivevalues list
    responded <- responded[inserted$val]
    
    
    # Total number of patients in the study
    total <- c(input$ntotal1, input$ntotal2, input$ntotal3, input$ntotal4, input$ntotal5, 
               input$ntotal6, input$ntotal7, input$ntotal8, input$ntotal9, input$ntotal10, 
               input$ntotal11, input$ntotal12, input$ntotal13, input$ntotal14, input$ntotal15,
               input$ntotal16, input$ntotal17, input$ntotal18, input$ntotal19, input$ntotal20,
               input$ntotal21, input$ntotal22, input$ntotal23, input$ntotal24, input$ntotal25,
               input$ntotal26, input$ntotal27, input$ntotal28, input$ntotal29, input$ntotal30,
               input$ntotal31, input$ntotal32, input$ntotal33, input$ntotal34, input$ntotal35,
               input$ntotal36, input$ntotal37, input$ntotal38, input$ntotal39, input$ntotal40,
               input$ntotal41, input$ntotal42, input$ntotal43, input$ntotal44, input$ntotal45,
               input$ntotal46, input$ntotal47, input$ntotal48, input$ntotal49, input$ntotal50,
               input$ntotal51, input$ntotal52, input$ntotal53, input$ntotal54, input$ntotal55,
               input$ntotal56, input$ntotal57, input$ntotal58, input$ntotal59, input$ntotal60,
               input$ntotal61, input$ntotal62, input$ntotal63, input$ntotal64, input$ntotal65,
               input$ntotal66, input$ntotal67, input$ntotal68, input$ntotal69, input$ntotal70,
               input$ntotal71, input$ntotal72, input$ntotal73, input$ntotal74, input$ntotal75,
               input$ntotal76, input$ntotal77, input$ntotal78, input$ntotal79, input$ntotal80,
               input$ntotal81, input$ntotal82, input$ntotal83, input$ntotal84, input$ntotal85,
               input$ntotal86, input$ntotal87, input$ntotal88, input$ntotal89, input$ntotal90,
               input$ntotal91, input$ntotal92, input$ntotal93, input$ntotal94, input$ntotal95,
               input$ntotal96, input$ntotal97, input$ntotal98, input$ntotal99, input$ntotal100)
    # Consider only those totals from studies that have not been deleted and are in the interactive reactivevalues list
    total <- total[inserted$val]
    
    # Save variables in dataframe
    data_metaanalysis <- data.frame(Treatments, studies, responded, total)
    
    # Select only the data for oral steroids
    data_metaanalysis_PRD <- data_metaanalysis[Treatments=="Oral steroids", ]

    
    ## If there is no adjustment for publication bias, create the regular forest plot
    if (input$checkbox_publication_bias==FALSE) {      
    
        
    # Collect the data for the metaanalysis in a metaprop object    
    dataformetaanalysisPRD <- metaprop(
      # Patients who responded
      event = as.numeric(as.character(data_metaanalysis_PRD$responded)),
      # Total number of patients in the study
      n = as.numeric(as.character(data_metaanalysis_PRD$total)),
      # Study names
      studlab = data_metaanalysis_PRD$studies,
      # Classification variable (type of treatment)
      byvar = data_metaanalysis_PRD$Treatments,                     
      method="Inverse"
    )
    
    # Create the publication bias plot
    publicationbiasplotPRD <- funnel(dataformetaanalysisPRD, comb.fixed = FALSE, comb.random = TRUE, 
                                      pch = 21, cex = 1.5,
                                      lty.random = 2, lwd.random = 2, bg = "navy", col = "navy",
                                      studlab = FALSE)
    
    
    # Render the publication bias plot
    publicationbiasplotPRD

    
    ## If there is adjustment for publication bias, create the forest plot with imputted studies
    } else {
      
      # Collect the data for the metaanalysis for oral steroids in a metaprop object    
      dataformetaanalysisPRD <- metaprop(
        # Patients who responded
        event = as.numeric(as.character(data_metaanalysis_PRD$responded)),
        # Total number of patients in the study
        n = as.numeric(as.character(data_metaanalysis_PRD$total)),
        # Study names
        studlab = data_metaanalysis_PRD$studies,
        # Classification variable (type of treatment)
        byvar = data_metaanalysis_PRD$Treatments,                     
        method="Inverse"
      )
      
      # Trim-and-fill the data for oral steroids
      PRD_trimandfill <- trimfill(dataformetaanalysisPRD, ma.fixed = TRUE, comb.random = TRUE)
      
      # Create the publication bias plot
      publicationbiasplotPRD <- funnel(PRD_trimandfill, comb.fixed = FALSE, comb.random = TRUE, 
                                        pch = 21, cex = 1.5,
                                        lty.random = 2, lwd.random = 2, 
                                        bg = c(rep("navy", length(dataformetaanalysisPRD$studlab)), 
                                               rep("red", length(PRD_trimandfill$studlab)-length(dataformetaanalysisPRD$studlab))), 
                                        col = c(rep("navy", length(dataformetaanalysisPRD$studlab)), 
                                                rep("red", length(PRD_trimandfill$studlab)-length(dataformetaanalysisPRD$studlab))),
                                        studlab = FALSE)
      
      
      # Render the publication bias plot
      publicationbiasplotPRD      
      
    }    
    
        
  }, width = 400, height = 400)  
  
  
  
}
##########################################################################################################################
##########################################################END OF SERVER################################################
##########################################################################################################################





##########################################################################################################################
##########################################################RUN THE APP WITH UI AND SERVER###############################################
##########################################################################################################################
#### Run the app
shinyApp(ui = ui, server = server)