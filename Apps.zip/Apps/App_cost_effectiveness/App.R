#### Copyleft Ivan Sanchez Fernandez 2020

# ui.R
library(shiny)
library(ggplot2)
library(plotly)
# App appearance
ui <- fluidPage(
  # Beginning of fluidPage
  
  tags$br(),
  tags$strong("COST-EFFECTIVENESS OF INTRAMUSCULAR ACTH VERSUS ORAL PREDNISOLONE FOR INFANTILE SPASMS"),
  tags$br(),
  tags$br(),
  tags$strong("Explore how different inputs modify cost-effectiveness"),
  tags$br(),
  tags$header("Remember to enter appropriate inputs into the model: proportions should go from 0 to 1, the cost of No treatment should be 0, and the rest of the costs cannot be negative. With inappropriate inputs the model will return inappropriate outputs or errors"),
  tags$br(),
  
  sidebarLayout(
    # Beginning of sidebarLayout
    
    sidebarPanel(
      # Beginning of sidebarPanel
      
  fluidRow(

    column(6,
           # Title
           tags$strong("INPUT"),    
           tags$br(),
           tags$br(),
           tags$br(),
           tags$br(),
           tags$strong("COST ($)"),
           tags$br(),
           tags$strong("(TREATMENT FOR 14-DAYS)"),
           tags$br(),
           tags$br(),
           tags$br(),
  ## INPUTS
  # Input cost of treatments
  textInput(inputId = "c.Notreatment",
               label = "No treatment",
               value = 0,
            width = 150),
  textInput(inputId = "c.ACTH",
               label = "ACTH",
               value = 100464,
            width = 150),  
  textInput(inputId = "c.PRD",
               label = "Prednisolone",
               value = 210,
            width = 150)   
  ), 

  column(6, 
         tags$br(),
         tags$br(),   
         tags$br(),
         tags$br(),
         tags$strong("SPASMS RESOLUTION (SR)"),
         tags$br(),
         tags$strong("(PROBABILITY SR)"),
         tags$br(),
         tags$br(),
         tags$br(),
  # Input probabilities into the model
  textInput(inputId = "p.NotreatmentSR",
               label = "No treatment",
               value = 0,
            width = 150),  
  textInput(inputId = "p.ACTHSR",
               label = "ACTH",
               value = 0.70,
            width = 150),   
  textInput(inputId = "p.PRDSR",
               label = "Prednisolone",
               value = 0.63,
            width = 150)
  )
  ),img(src = 'Figuretree.png', height = "100%", width = "100%")
  
  # End of sidebarPanel
  ), 
  
  mainPanel(
    # Beginning of mainPanel
    
  ## OUTPUTS  

  column(12, offset = 1,
         # ICER table
         tags$strong("OUTPUT"),
         tags$br(),
         tags$br(),
         tags$strong("Cost-effectiveness referenced to common baseline of no treatment:"),
         textOutput("ICERbaseline"),
         tags$header("For illustrative purposes only."),
         tags$header("The most common measure of cost-effectiveness is the ICER referenced to the next most cost-effective alternative as presented in the Cost-Effectiveness Table."),
         
         
         tags$br(),
         tags$br(),
         tags$strong("COST-EFFECTIVENESS TABLE"),
         tags$br(),
         tags$br(),  
         tableOutput("ICER"),
         tags$strong("*Strategies that are not cost-effective dissappear from the table"),
         tags$br(),
         tags$strong("Legend: IE: incremental effectiveness. IC: incremental cost. ICER: incremental cost-effectiveness ratio."),
         
         
         #CE graph
         tags$br(),
         tags$br(),
         tags$br(),
         tags$br(),
         tags$strong("COST-EFFECTIVENESS PLOT"),
         tags$br(),  
         tags$br(), 
         plotlyOutput("plotCE", width = 800, height = 500),
         tags$br(),
         tags$strong("Legend: Notreatment: No treatment. ACTH: Intramuscular ACTH. PRD: Oral prednisolone. $: USA dollars. SR: Probability of spasms resolution."))

  # End of mainPanel
  )

# End of sidebarLayout
),
tags$br(),
tags$br(),
tags$header("Ivan Sanchez Fernandez 2020. This work is copylefted under a General Public Licence (GPL)."),
tags$header("Users are fee to run, study, and modify this software and to share and distribute original or modified versions of this software.")

# End of fluidPage
)







# server.R
library(shiny)
library(ggplot2)
library(plotly)

server <- function(input, output) {
  
  
  
  # ICER REFERENCED TO COMMON BASELINE
  
  output$ICERbaseline <- renderText({
    
    # Define the values based on the inputs
    p.NotreatmentSR <- as.numeric(as.character(input$p.NotreatmentSR))
    p.ACTHSR <- as.numeric(as.character(input$p.ACTHSR))
    p.PRDSR <- as.numeric(as.character(input$p.PRDSR))
    
    
    c.ACTH <- as.numeric(as.character(input$c.ACTH))
    c.PRD <- as.numeric(as.character(input$c.PRD))
    
    
    # Define the cost-effectiveness referenced to common baseline of no AED
    CEACTH <- c.ACTH / p.ACTHSR
    CEPRD <- c.PRD / p.PRDSR
    
    # Save values into a dataframe
    CEbaselinevector <- c(CEACTH, CEPRD)
    CEbaselinenames <- c("ACTH", "PRD")
    CEbaseline <- data.frame(CEbaselinenames, CEbaselinevector)
    
    # Order by ascending CE
    CEbaseline <- CEbaseline[order(CEbaseline$CEbaselinevector), ]
    
    # Produce the text
    CEbaseline$CEbaselinenames <- as.character(CEbaseline$CEbaselinenames)
    CEbaseline$CEbaselinevector <- round(CEbaseline$CEbaselinevector, digits = 2)
    CEbaseline$CEbaselinevector <- as.character(CEbaseline$CEbaselinevector)
    finaltext <- capture.output(cat(c(CEbaseline[1, 1], ": ", CEbaseline[1, 2], ";   ",  
                                      CEbaseline[2, 1], ": ", CEbaseline[2, 2]
    ),
    sep = ""))
    finaltext

  })
  
  
  
  
  
  
  ## INCREMENTAL COST EFFECTIVENESS TABLE
    output$ICER <- renderTable({
    
    # Define the values based on the inputs
    c.Notreatment <- as.numeric(as.character(input$c.Notreatment))  
    c.ACTH <- as.numeric(input$c.ACTH)
    c.PRD <- as.numeric(input$c.PRD)
      
    p.NotreatmentSR <- as.numeric(as.character(input$p.NotreatmentSR))
    p.ACTHSR <- as.numeric(as.character(input$p.ACTHSR))
    p.PRDSR <- as.numeric(as.character(input$p.PRDSR))

    
    ## Utility of outcomes
    u.SR <- 1
    u.NoSR <- 0
    
    
    ## Effectiveness into the model
    e.Notreatment <- (u.SR * p.NotreatmentSR) + (u.NoSR * (1 - p.NotreatmentSR))
    e.ACTH <- (u.SR * p.ACTHSR) + (u.NoSR * (1 - p.ACTHSR))
    e.PRD <- (u.SR * p.PRDSR) + (u.NoSR * (1 - p.PRDSR))

    
    
    ######FUNCTION FOR INCREMENTAL COST EFFECTIVENESS
    
    ## Create dataframe with cost and effectiveness data
    Cost <- c(c.Notreatment, c.ACTH, c.PRD)
    Effectiveness <- c(e.Notreatment, e.ACTH, e.PRD)
    Names <- c("No treatment", "ACTH", "Prednisolone")
    ACTHvsPRD <- data.frame(Names, Cost, Effectiveness)
    
    #Save dataframe for plot
    ACTHvsPRDforplot <- ACTHvsPRD
    
    ACTHvsPRD$Cost <- as.numeric(as.character(ACTHvsPRD$Cost))
    ## Sort by cost
    ACTHvsPRD <- ACTHvsPRD[order(Cost), ]
    
    
    
    ### SORT BY COST AND ELIMINATE STRONGLY DOMINATED OPTIONS    
    for (i in 1 : length(ACTHvsPRD$Cost)) {
      
      # Calculate incremental effectiveness
      for (j in 1 : (length(ACTHvsPRD$Cost) - 1)){
        ACTHvsPRD$IE[1] <- ACTHvsPRD$Effectiveness[1]
        ACTHvsPRD$IE[j + 1] <- ACTHvsPRD$Effectiveness[j + 1] - ACTHvsPRD$Effectiveness[j]
      }
      
      # Identify the first row where the incremental effectiveness is negative
      firstrownegativeIE <- which (ACTHvsPRD$IE < 0)[1]
      
      # Are there more negatives?
      nomorenegatives <- ifelse(is.na(firstrownegativeIE) == TRUE, 1, 0)
      
      
      
      if (nomorenegatives == 1) {
        break
      } else{
        ## Eliminate the first row where the incremental effectiveness is negative
        ACTHvsPRD <- ACTHvsPRD[- firstrownegativeIE, ]
        # Eliminate rows with NA
        ACTHvsPRD <- ACTHvsPRD[!is.na(ACTHvsPRD$Names), ]
        # Renumber the rows
        rownames(ACTHvsPRD) <- seq(length=nrow(ACTHvsPRD))
      } 
      
    }
    # Eliminate rows with NA
    ACTHvsPRD <- ACTHvsPRD[!is.na(ACTHvsPRD$Names), ]
    
    
    
    ### CALCULATE ICER AND ELIMINATE OPTIONS BY EXTENDED DOMINANCE
    for (l in 1 : length(ACTHvsPRD$Cost)){    
      
      # Calculate incremental effectiveness
      for (j in 1 : (length(ACTHvsPRD$Cost) - 1)){
        ACTHvsPRD$IE[1] <- ACTHvsPRD$Effectiveness[1]
        ACTHvsPRD$IE[j + 1] <- ACTHvsPRD$Effectiveness[j + 1] - ACTHvsPRD$Effectiveness[j]
      }
      
      # Calculate incremental cost
      for (k in 1 : (length(ACTHvsPRD$Cost) - 1)){
        ACTHvsPRD$IC[1] <- ACTHvsPRD$Cost[1]
        ACTHvsPRD$IC[k + 1] <- ACTHvsPRD$Cost[k + 1] - ACTHvsPRD$Cost[k]
      }
      
      ## Calculate incremental cost effectiveness
      for (h in 1 : (length(ACTHvsPRD$Cost) - 1)) {
        ACTHvsPRD$ICER[1] <- ACTHvsPRD$IC[1] / ACTHvsPRD$IE[1]
        ACTHvsPRD$ICER[h + 1] <- ACTHvsPRD$IC[h + 1] / ACTHvsPRD$IE[h + 1]
      }
      
      # Calculate if some ICER is higher than the next
      for (m in 1 : length(ACTHvsPRD$Cost)) {
        ACTHvsPRD$ICERdifference[m] <- ACTHvsPRD$ICER[m + 1] - ACTHvsPRD$ICER[m]
      }
      
      # Identify the first row where the incremental effectiveness is negative
      firstrownegativeICERdifference <- which (ACTHvsPRD$ICERdifference < 0)[1]
      
      # Are there more negatives?
      nomorenegativesICERdifference <- ifelse(is.na(firstrownegativeICERdifference) == TRUE, 1, 0)
      
      
      
      if (nomorenegativesICERdifference == 1) {
        break
      } else{
        ## Eliminate the first row where the ICERdifference is negative
        ACTHvsPRD <- ACTHvsPRD[- firstrownegativeICERdifference, ]
        # Eliminate rows with NA
        ACTHvsPRD <- ACTHvsPRD[!is.na(ACTHvsPRD$Names), ]
        # Renumber the rows
        rownames(ACTHvsPRD) <- seq(length = nrow(ACTHvsPRD))
      }
      
    }
    # Eliminate rows with NA
    ACTHvsPRD <- ACTHvsPRD[!is.na(ACTHvsPRD$Names), ]  
    
    # Eliminate ICERdifference column
    ACTHvsPRD <- ACTHvsPRD[ , - 7]

    ACTHvsPRD
  })
  
  
  
  
## PLOT  
  output$plotCE <- renderPlotly({
    
    # Define the values based on the inputs
    c.Notreatment <- as.numeric(as.character(input$c.Notreatment))  
    c.ACTH <- as.numeric(input$c.ACTH)
    c.PRD <- as.numeric(input$c.PRD)
    
    p.NotreatmentSR <- as.numeric(as.character(input$p.NotreatmentSR))
    p.ACTHSR <- as.numeric(as.character(input$p.ACTHSR))
    p.PRDSR <- as.numeric(as.character(input$p.PRDSR))
    
    
    ## Utility of outcomes
    u.SR <- 1
    u.NoSR <- 0
    
    
    ## Effectiveness into the model
    e.Notreatment <- (u.SR * p.NotreatmentSR) + (u.NoSR * (1 - p.NotreatmentSR))
    e.ACTH <- (u.SR * p.ACTHSR) + (u.NoSR * (1 - p.ACTHSR))
    e.PRD <- (u.SR * p.PRDSR) + (u.NoSR * (1 - p.PRDSR))
 
    
  
    ## Create dataframe with cost and effectiveness data
    Cost <- c(c.Notreatment, c.ACTH, c.PRD)
    Effectiveness <- c(e.Notreatment, e.ACTH, e.PRD)
    Names <- c("Notreatment", "ACTH", "PRD")
    ACTHvsPRD <- data.frame(Names, Cost, Effectiveness)
    
    #Save dataframe for plot
    ACTHvsPRDforplot <- ACTHvsPRD    
    
         
    
    # Order factors
    ACTHvsPRDforplot$Names <- factor(ACTHvsPRDforplot$Names, levels = c("Notreatment", "ACTH", "PRD"))  # Plot CE
    plotCE <- ggplot(data = ACTHvsPRDforplot, aes(x = Effectiveness, y = Cost, 
                                                   color = Names)) +
      geom_point(size = 5, pch = c(22, 24, 21),
                 bg = c("Notreatment"="darkorange", "ACTH"="red", "PRD"="darkgreen")) +
      theme(panel.background = element_rect(fill = "white"), 
            axis.text = element_text(size = 10, color = "black", face = "bold"),
            axis.title = element_text(size = 16, color = "black", face = "bold"),
            axis.ticks.length = unit(0.2, "cm"), axis.ticks = element_line(size = 1),
            axis.line.x = element_line(color="black", size = 1),
            axis.line.y = element_line(color="black", size = 1), 
            legend.key = element_rect(fill = "white"), legend.position = "bottom") +
      scale_colour_manual(name="",  
                          values = c("Notreatment"="darkorange", "ACTH"="red", "PRD"="darkgreen")) +
      labs(x= "Effectiveness (SR)", y= "Cost ($)")
    
    # Make the plot interactive
    plotCE <- ggplotly(plotCE)
    plotCE
    
  })

}



# Run the app
shinyApp(ui = ui, server = server)
